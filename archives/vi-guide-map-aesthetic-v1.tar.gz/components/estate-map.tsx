"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import type { LineString, Position } from "geojson";
import type { LatLngBoundsExpression, LatLngExpression } from "leaflet";
import L from "leaflet";
import {
  Circle,
  CircleMarker,
  MapContainer,
  Marker,
  Pane,
  Polygon,
  Polyline,
  Popup,
  TileLayer,
  Tooltip,
  ZoomControl,
  useMap,
} from "react-leaflet";

import "leaflet/dist/leaflet.css";

import type { EstateRecord, IslandCode } from "@/types/usvi";

type Lens = "beaches" | "places" | "stays" | "historic" | "drivers" | "demand";

type PlaceRecord = {
  id?: string;
  name?: string;
  title?: string;
  island?: IslandCode | string;
  lat?: number;
  lng?: number;
  category?: string;
  type?: string;
  location?: string;
  description?: string;
  rating?: number;
  image?: string;
};

type Props = {
  island: IslandCode;
  estates: EstateRecord[];
  places: PlaceRecord[];
  activeLens: Lens;
  selectedEstateGeoid: string | null;
  fromGeoid: string;
  toGeoid: string;
  routeGeoJson: LineString | null;
  routeFocusNonce: number;
  onSelectEstate: (estate: EstateRecord) => void;
  onSelectFrom: (geoid: string) => void;
  onSelectTo: (geoid: string) => void;
};

type DriverMarker = {
  id: string;
  label: string;
  lat: number;
  lng: number;
  status: "available" | "assigned" | "repositioning";
  nearEstate?: string;
};

type DemandHotspot = {
  id: string;
  label: string;
  lat: number;
  lng: number;
  radius: number;
  intensity: "low" | "medium" | "high";
};

const ISLAND_VIEW: Record<
  IslandCode,
  { center: LatLngExpression; zoom: number; bounds?: LatLngBoundsExpression }
> = {
  stt: {
    center: [18.336, -64.93],
    zoom: 12,
    bounds: [
      [18.27, -65.05],
      [18.42, -64.82],
    ],
  },
  stj: {
    center: [18.34, -64.75],
    zoom: 12,
    bounds: [
      [18.28, -64.86],
      [18.39, -64.64],
    ],
  },
  stx: {
    center: [17.746, -64.747],
    zoom: 11,
    bounds: [
      [17.67, -64.96],
      [17.81, -64.54],
    ],
  },
};

const estateStroke = "#67e8f9";
const estateFill = "#0891b2";
const selectedStroke = "#fbbf24";
const pickupStroke = "#14b8a6";
const destinationStroke = "#f59e0b";
const routeGlow = "#38bdf8";
const routeCore = "#2563eb";

const pickupIcon = makePinIcon("#14b8a6", "P");
const destinationIcon = makePinIcon("#f59e0b", "D");
const driverAvailableIcon = makeDriverIcon("#22c55e");
const driverAssignedIcon = makeDriverIcon("#3b82f6");
const driverRepositionIcon = makeDriverIcon("#f59e0b");

export function EstateMap({
  island,
  estates,
  places,
  activeLens,
  selectedEstateGeoid,
  fromGeoid,
  toGeoid,
  routeGeoJson,
  routeFocusNonce,
  onSelectEstate,
  onSelectFrom,
  onSelectTo,
}: Props) {
  const [showEstateLabels, setShowEstateLabels] = useState(false);
  const [selectedPlaceId, setSelectedPlaceId] = useState<string | null>(null);
  const [mapStyle, setMapStyle] = useState<"satellite" | "dark">("satellite");
  const [islandResetNonce, setIslandResetNonce] = useState(0);

  const showDrivers = activeLens === "drivers";
  const showDemand = activeLens === "demand";
  const showPlaces = !showDrivers && !showDemand;

  const constrainedTouchDevice = useMemo(() => {
    if (typeof navigator === "undefined") return false;

    const looksLikeIPad =
      /iPad/i.test(navigator.userAgent) ||
      (/Macintosh/i.test(navigator.userAgent) && navigator.maxTouchPoints > 1);
    const deviceMemory = (navigator as Navigator & { deviceMemory?: number })
      .deviceMemory;

    return looksLikeIPad || (deviceMemory !== undefined && deviceMemory <= 4);
  }, []);

  const selectedEstate =
    estates.find((estate) => estate.geoid === selectedEstateGeoid) ?? null;
  const fromEstate =
    estates.find((estate) => estate.geoid === fromGeoid) ?? null;
  const toEstate = estates.find((estate) => estate.geoid === toGeoid) ?? null;

  const routeLatLngs = useMemo(
    () => geoJsonLineToLatLngs(routeGeoJson),
    [routeGeoJson]
  );

  const validPlaces = useMemo(
    () =>
      places.filter(
        (place) =>
          typeof place.lat === "number" && typeof place.lng === "number"
      ),
    [places]
  );

  const selectedPlace = useMemo(
    () =>
      validPlaces.find(
        (place, index) =>
          (place.id || `${place.name || place.title || "Place"}-${index}`) === selectedPlaceId
      ) ?? null,
    [selectedPlaceId, validPlaces]
  );

  useEffect(() => {
    setSelectedPlaceId(null);
  }, [activeLens, island]);

  const nearestEstateToSelectedPlace = useMemo(() => {
    if (!selectedPlace || typeof selectedPlace.lat !== "number" || typeof selectedPlace.lng !== "number") return null;
    return estates
      .map((estate) => ({
        estate,
        distance:
          Math.pow(estate.internalPoint.lat - selectedPlace.lat!, 2) +
          Math.pow(estate.internalPoint.lng - selectedPlace.lng!, 2),
      }))
      .sort((a, b) => a.distance - b.distance)[0]?.estate ?? null;
  }, [estates, selectedPlace]);

  const driverMarkers = useMemo(
    () => buildSyntheticDrivers(estates, island),
    [estates, island]
  );

  const demandHotspots = useMemo(
    () => buildDemandHotspots(estates, validPlaces, island),
    [estates, validPlaces, island]
  );

  const selectedEstateBounds = useMemo(
    () => getEstateBounds(selectedEstate),
    [selectedEstate]
  );

  return (
    <div className="relative overflow-hidden rounded-[28px] border border-white/10 bg-[#06131b]">
      <div className="pointer-events-none absolute inset-x-0 top-0 z-[1000] flex flex-col gap-3 border-b border-white/10 bg-[linear-gradient(180deg,rgba(3,10,18,0.92),rgba(3,10,18,0.72),transparent)] px-4 py-4 md:px-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="text-[11px] font-black uppercase tracking-[0.28em] text-amber-300">
              Live territory canvas
            </div>
            <div className="mt-1 text-xl font-black italic tracking-tight text-white md:text-2xl">
              {selectedEstate
                ? `${selectedEstate.baseName} active`
                : fromEstate && toEstate
                ? `${fromEstate.baseName} → ${toEstate.baseName}`
                : "Explore official estate geography"}
            </div>
          </div>

          <div className="pointer-events-auto flex flex-wrap gap-2">
            <span className="rounded-full border border-cyan-300/30 bg-cyan-300/10 px-3 py-2 text-[10px] font-black uppercase tracking-[0.16em] text-cyan-100">
              {lensLabel(activeLens)} lens · {showDrivers ? driverMarkers.length : showDemand ? demandHotspots.length : validPlaces.length} visible
            </span>
            <MapToggle
              active={showEstateLabels}
              label="Estate labels"
              onClick={() => setShowEstateLabels((v) => !v)}
            />
          </div>
        </div>

        <div className="grid gap-2 md:grid-cols-4 pointer-events-none">
          <TopMetric
            label="Selected"
            value={selectedEstate?.baseName || "None"}
            tone="cyan"
          />
          <TopMetric
            label="Pickup"
            value={fromEstate?.baseName || "Not set"}
            tone="teal"
          />
          <TopMetric
            label="Destination"
            value={toEstate?.baseName || "Not set"}
            tone="amber"
          />
          <TopMetric
            label="Route"
            value={
              routeLatLngs.length > 1 ? "Active roadway path" : "No route yet"
            }
            tone="slate"
          />
        </div>
      </div>

      <div className="absolute left-4 top-[168px] z-[1050] hidden w-[220px] overflow-hidden rounded-[22px] border border-white/15 bg-[#061520e8] shadow-[0_18px_50px_rgba(0,0,0,0.42)] backdrop-blur-xl xl:block">
        <div className="border-b border-white/10 px-4 py-3">
          <div className="text-[9px] font-black uppercase tracking-[0.22em] text-white/45">Live map layers</div>
          <div className="mt-1 text-sm font-black text-white">{lensLabel(activeLens)} layer</div>
        </div>
        <div className="space-y-1 p-2">
          <LayerRow label="Restaurants" count={countPlaces(validPlaces, ["restaurant", "food", "dining"])} color="#f97316" active={activeLens === "places"} />
          <LayerRow label="Beaches" count={countPlaces(validPlaces, ["beach", "bay"])} color="#22d3ee" active={activeLens === "beaches"} />
          <LayerRow label="Historic" count={countPlaces(validPlaces, ["historic", "museum", "fort"])} color="#a78bfa" active={activeLens === "historic"} />
          <LayerRow label="Stays" count={countPlaces(validPlaces, ["stay", "hotel", "villa", "resort"])} color="#60a5fa" active={activeLens === "stays"} />
          <LayerRow label="Drivers" count={driverMarkers.length} color="#2dd4bf" active={activeLens === "drivers"} />
          <LayerRow label="Demand" count={demandHotspots.length} color="#f59e0b" active={activeLens === "demand"} />
        </div>
        <div className="flex items-center justify-between border-t border-white/10 px-4 py-3">
          <span className="text-[10px] font-bold text-white/45">Visible results</span>
          <span className="text-lg font-black text-cyan-200">{showDrivers ? driverMarkers.length : showDemand ? demandHotspots.length : validPlaces.length}</span>
        </div>
      </div>

      <div className="absolute right-4 top-[168px] z-[1050] flex gap-2">
        <button type="button" onClick={() => setMapStyle((value) => value === "satellite" ? "dark" : "satellite")} className="rounded-xl border border-white/15 bg-[#061520e8] px-3 py-2 text-[10px] font-black uppercase tracking-[0.12em] text-white shadow-lg backdrop-blur-xl hover:bg-[#0a2230]">
          {mapStyle === "satellite" ? "Satellite" : "Dark map"}
        </button>
        <button type="button" onClick={() => setIslandResetNonce((value) => value + 1)} className="rounded-xl border border-white/15 bg-[#061520e8] px-3 py-2 text-[10px] font-black uppercase tracking-[0.12em] text-white shadow-lg backdrop-blur-xl hover:bg-[#0a2230]">
          Full island
        </button>
      </div>

      <div className="h-[780px] w-full">
        <MapContainer
          center={ISLAND_VIEW[island].center}
          zoom={ISLAND_VIEW[island].zoom}
          zoomControl={false}
          className="h-full w-full bg-[#071019]"
          preferCanvas
          touchZoom={true}
          doubleClickZoom={false}
          zoomAnimation={!constrainedTouchDevice}
          fadeAnimation={!constrainedTouchDevice}
          markerZoomAnimation={!constrainedTouchDevice}
          inertia={!constrainedTouchDevice}
        >
          <ZoomControl position="bottomright" />

          <Pane name="territory-vectors" style={{ zIndex: 400 }} />
          <Pane name="drivers" style={{ zIndex: 550 }} />
          <Pane name="route" style={{ zIndex: 650 }} />
          <Pane name="pins" style={{ zIndex: 700 }} />

          {mapStyle === "satellite" ? (
            <>
              <TileLayer
                attribution="Tiles &copy; Esri"
                url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
                updateWhenIdle
                updateWhenZooming={false}
                keepBuffer={1}
              />
              <TileLayer
                attribution="Labels &copy; Esri"
                url="https://services.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}"
                opacity={0.72}
                updateWhenIdle
                updateWhenZooming={false}
                keepBuffer={1}
              />
            </>
          ) : (
            <TileLayer
              attribution="&copy; OpenStreetMap contributors &copy; CARTO"
              url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
              updateWhenIdle
              updateWhenZooming={false}
              keepBuffer={1}
            />
          )}

          {showDemand &&
            demandHotspots.map((hotspot) => (
              <DemandLayer key={hotspot.id} hotspot={hotspot} />
            ))}

          {estates.map((estate) => {
            const rings = getEstatePolygonRings(estate);
            if (!rings.length) return null;

            const isSelected = estate.geoid === selectedEstateGeoid;
            const isPickup = estate.geoid === fromGeoid;
            const isDestination = estate.geoid === toGeoid;

            const stroke = isPickup
              ? pickupStroke
              : isDestination
              ? destinationStroke
              : isSelected
              ? selectedStroke
              : estateStroke;

            const fillColor = isPickup
              ? "#14b8a6"
              : isDestination
              ? "#f59e0b"
              : isSelected
              ? "#0ea5e9"
              : estateFill;

            const fillOpacity =
              isPickup || isDestination || isSelected ? 0.26 : 0.14;

            const visibleWeight =
              isPickup || isDestination || isSelected ? 3.5 : 1.75;

            return (
              <Polygon
                key={estate.geoid}
                pane="territory-vectors"
                  positions={rings}
                  interactive={true}
                  pathOptions={{
                    color: stroke,
                    weight: visibleWeight,
                    fillColor,
                    fillOpacity,
                    opacity: 0.95,
                  }}
                  eventHandlers={{
                    click: () => onSelectEstate(estate),
                    contextmenu: () => onSelectFrom(estate.geoid),
                    dblclick: () => onSelectTo(estate.geoid),
                  }}
                >
                  <Popup className="estate-popup">
                    <div className="min-w-[220px]">
                      <div className="text-xs font-black uppercase tracking-[0.22em] text-slate-500">
                        Estate
                      </div>
                      <div className="mt-1 text-lg font-black text-slate-900">
                        {estate.baseName}
                      </div>
                      <div className="mt-1 text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">
                        {estate.fullName || "Official estate record"}
                      </div>

                      <div className="mt-4 grid gap-2">
                        <button
                          type="button"
                          onClick={() => onSelectEstate(estate)}
                          className="rounded-xl bg-slate-900 px-3 py-2 text-xs font-black uppercase tracking-[0.16em] text-white"
                        >
                          Focus estate
                        </button>
                        <button
                          type="button"
                          onClick={() => onSelectFrom(estate.geoid)}
                          className="rounded-xl bg-teal-600 px-3 py-2 text-xs font-black uppercase tracking-[0.16em] text-white"
                        >
                          Use as pickup
                        </button>
                        <button
                          type="button"
                          onClick={() => onSelectTo(estate.geoid)}
                          className="rounded-xl bg-amber-400 px-3 py-2 text-xs font-black uppercase tracking-[0.16em] text-[#5b3800]"
                        >
                          Use as destination
                        </button>
                      </div>
                    </div>
                  </Popup>

                  {showEstateLabels || isSelected ? (
                    <Tooltip
                      direction="center"
                      permanent={isSelected}
                      sticky={!isSelected && !constrainedTouchDevice}
                      opacity={1}
                      className="estate-label"
                    >
                      <div className="rounded-full border border-white/10 bg-[#05121bcc] px-3 py-1.5 text-[10px] font-black uppercase tracking-[0.14em] text-white shadow-[0_6px_30px_rgba(0,0,0,0.28)]">
                        {estate.baseName}
                      </div>
                    </Tooltip>
                  ) : null}
              </Polygon>
            );
          })}

          {showPlaces &&
            validPlaces.map((place, index) => {
              const label = place.name || place.title || `Place ${index + 1}`;
              const category = place.category || place.type || "place";

              return (
                <CircleMarker
                  key={place.id || `${label}-${index}`}
                  center={[place.lat as number, place.lng as number]}
                  pane="territory-vectors"
                  eventHandlers={{
                    click: () => setSelectedPlaceId(place.id || `${label}-${index}`),
                  }}
                  pathOptions={{
                    color: selectedPlaceId === (place.id || `${label}-${index}`) ? "#ffffff" : "#e2e8f0",
                    weight: selectedPlaceId === (place.id || `${label}-${index}`) ? 3 : 1,
                    fillColor: placeColor(category),
                    fillOpacity: 0.95,
                  }}
                  radius={selectedPlaceId === (place.id || `${label}-${index}`) ? 10 : 7}
                >
                  <Tooltip direction="top" offset={[0, -2]} opacity={1}>
                    <div className="rounded-full border border-white/10 bg-[#07131fcc] px-3 py-1.5 text-[10px] font-black uppercase tracking-[0.14em] text-white">
                      {label}
                    </div>
                  </Tooltip>
                </CircleMarker>
              );
            })}

          {showDrivers &&
            driverMarkers.map((driver) => (
              <Marker
                key={driver.id}
                position={[driver.lat, driver.lng]}
                pane="drivers"
                icon={
                  driver.status === "available"
                    ? driverAvailableIcon
                    : driver.status === "assigned"
                    ? driverAssignedIcon
                    : driverRepositionIcon
                }
              >
                <Popup>
                  <div className="min-w-[200px]">
                    <div className="text-xs font-black uppercase tracking-[0.2em] text-slate-500">
                      Driver
                    </div>
                    <div className="mt-1 text-base font-black text-slate-900">
                      {driver.label}
                    </div>
                    <div className="mt-2 text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">
                      Status: {driver.status}
                    </div>
                    {driver.nearEstate ? (
                      <div className="mt-1 text-xs font-semibold text-slate-600">
                        Near {driver.nearEstate}
                      </div>
                    ) : null}
                  </div>
                </Popup>
              </Marker>
            ))}

          {routeLatLngs.length > 1 ? (
            <>
              <Polyline
                pane="route"
                positions={routeLatLngs}
                pathOptions={{
                  color: routeGlow,
                  weight: 12,
                  opacity: 0.35,
                  lineCap: "round",
                  lineJoin: "round",
                }}
              />
              <Polyline
                pane="route"
                positions={routeLatLngs}
                pathOptions={{
                  color: routeCore,
                  weight: 5,
                  opacity: 0.95,
                  lineCap: "round",
                  lineJoin: "round",
                  dashArray: "10 10",
                }}
              />
            </>
          ) : null}

          {fromEstate ? (
            <Marker
              pane="pins"
              position={getEstateCenter(fromEstate)}
              icon={pickupIcon}
            />
          ) : null}

          {toEstate ? (
            <Marker
              pane="pins"
              position={getEstateCenter(toEstate)}
              icon={destinationIcon}
            />
          ) : null}

          <MapViewportController
            island={island}
            selectedEstateBounds={selectedEstateBounds}
            routeLatLngs={routeLatLngs}
            islandBounds={ISLAND_VIEW[island].bounds}
            routeFocusNonce={routeFocusNonce}
            islandResetNonce={islandResetNonce}
            animate={!constrainedTouchDevice}
          />
        </MapContainer>
      </div>

      {selectedPlace ? (
        <div className="pointer-events-auto absolute bottom-28 left-4 right-4 z-[1100] md:bottom-24 md:left-5 md:right-auto md:w-[390px]">
          <article className="overflow-hidden rounded-[24px] border border-white/15 bg-[#07131ff2] shadow-[0_24px_70px_rgba(0,0,0,0.55)] backdrop-blur-xl">
            <div className="flex items-start justify-between gap-4 p-4">
              <div className="min-w-0">
                <div className="text-[10px] font-black uppercase tracking-[0.2em] text-cyan-200">
                  {selectedPlace.category || selectedPlace.type || "Place"}
                </div>
                <h3 className="mt-1 truncate text-xl font-black text-white">
                  {selectedPlace.name || selectedPlace.title || "Selected place"}
                </h3>
                <p className="mt-1 text-sm text-white/60">
                  {selectedPlace.location || nearestEstateToSelectedPlace?.baseName || "US Virgin Islands"}
                  {typeof selectedPlace.rating === "number" ? ` · ★ ${selectedPlace.rating.toFixed(1)}` : ""}
                </p>
                {selectedPlace.description ? (
                  <p className="mt-3 line-clamp-2 text-sm leading-6 text-white/70">{selectedPlace.description}</p>
                ) : null}
              </div>
              <button
                type="button"
                onClick={() => setSelectedPlaceId(null)}
                aria-label="Close place card"
                className="shrink-0 rounded-full border border-white/10 bg-white/5 px-3 py-2 text-xs font-black text-white/70 hover:bg-white/10"
              >
                Close
              </button>
            </div>
            <div className="grid grid-cols-3 gap-2 border-t border-white/10 p-3">
              <button
                type="button"
                disabled={!nearestEstateToSelectedPlace}
                onClick={() => nearestEstateToSelectedPlace && onSelectEstate(nearestEstateToSelectedPlace)}
                className="rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-xs font-black text-white transition hover:bg-white/10 disabled:opacity-40"
              >
                Explore area
              </button>
              <button
                type="button"
                disabled={!nearestEstateToSelectedPlace}
                onClick={() => nearestEstateToSelectedPlace && onSelectTo(nearestEstateToSelectedPlace.geoid)}
                className="rounded-xl bg-cyan-300 px-3 py-2.5 text-xs font-black text-[#06202a] transition hover:bg-cyan-200 disabled:opacity-40"
              >
                Directions
              </button>
              <button
                type="button"
                onClick={() => savePlaceToTrip(selectedPlace)}
                className="rounded-xl border border-amber-300/30 bg-amber-300/10 px-3 py-2.5 text-xs font-black text-amber-100 transition hover:bg-amber-300/20"
              >
                Add to trip
              </button>
            </div>
          </article>
        </div>
      ) : null}

      <div className="pointer-events-none absolute inset-x-0 bottom-0 z-[1000] flex flex-col gap-3 border-t border-white/10 bg-[linear-gradient(0deg,rgba(2,8,14,0.94),rgba(2,8,14,0.74),transparent)] px-4 py-4 md:flex-row md:items-end md:justify-between md:px-5">
        <div className="grid flex-1 gap-2 md:max-w-[700px] md:grid-cols-3">
          <LegendItem color="#14b8a6" label="Pickup estate" />
          <LegendItem color="#f59e0b" label="Destination estate" />
          <LegendItem color="#38bdf8" label="Active roadway route" />
        </div>

        <div className="grid gap-2 md:grid-cols-3">
          <BottomMetric
            label="Drivers visible"
            value={showDrivers ? String(driverMarkers.length) : "Hidden"}
          />
          <BottomMetric
            label="Demand zones"
            value={showDemand ? String(demandHotspots.length) : "Hidden"}
          />
          <BottomMetric
            label="Places"
            value={showPlaces ? String(validPlaces.length) : "Hidden"}
          />
        </div>
      </div>
    </div>
  );
}

function LayerRow({ label, count, color, active }: { label: string; count: number; color: string; active: boolean }) {
  return (
    <div className={`flex items-center justify-between rounded-xl px-3 py-2.5 ${active ? "bg-white/10" : "bg-white/[0.025]"}`}>
      <div className="flex items-center gap-2.5">
        <span className="h-2.5 w-2.5 rounded-full ring-4 ring-white/5" style={{ backgroundColor: color }} />
        <span className={`text-xs font-bold ${active ? "text-white" : "text-white/55"}`}>{label}</span>
      </div>
      <span className="rounded-md bg-black/25 px-2 py-1 text-[10px] font-black text-white/70">{count}</span>
    </div>
  );
}

function countPlaces(places: PlaceRecord[], keywords: string[]) {
  return places.filter((place) => {
    const haystack = `${place.category ?? ""} ${place.type ?? ""}`.toLowerCase();
    return keywords.some((keyword) => haystack.includes(keyword));
  }).length;
}

function MapViewportController({
  island,
  selectedEstateBounds,
  routeLatLngs,
  islandBounds,
  routeFocusNonce,
  islandResetNonce,
  animate,
}: {
  island: IslandCode;
  selectedEstateBounds: LatLngBoundsExpression | null;
  routeLatLngs: LatLngExpression[];
  islandBounds?: LatLngBoundsExpression;
  routeFocusNonce: number;
  islandResetNonce: number;
  animate: boolean;
}) {
  const map = useMap();
  const lastIslandRef = useRef<IslandCode>(island);

  useEffect(() => {
    if (islandBounds) {
      map.fitBounds(islandBounds, { padding: [34, 34], animate });
    } else {
      map.setView(ISLAND_VIEW[island].center, ISLAND_VIEW[island].zoom, { animate });
    }
  }, [animate, island, islandBounds, islandResetNonce, map]);

  useEffect(() => {
    if (lastIslandRef.current !== island) {
      lastIslandRef.current = island;
      if (islandBounds) {
        map.fitBounds(islandBounds, {
          padding: [40, 40],
          animate,
        });
      } else {
        map.setView(ISLAND_VIEW[island].center, ISLAND_VIEW[island].zoom, {
          animate,
        });
      }
    }
  }, [animate, island, islandBounds, map]);

  useEffect(() => {
    if (routeLatLngs.length > 1) {
      const bounds = L.latLngBounds(routeLatLngs as LatLngExpression[]);
      map.fitBounds(bounds, {
        padding: [80, 80],
        animate,
      });
      return;
    }

    if (selectedEstateBounds) {
      map.fitBounds(selectedEstateBounds, {
        padding: [60, 60],
        animate,
      });
    }
  }, [animate, map, selectedEstateBounds, routeLatLngs, routeFocusNonce]);

  return null;
}

function DemandLayer({ hotspot }: { hotspot: DemandHotspot }) {
  const fillColor =
    hotspot.intensity === "high"
      ? "#f97316"
      : hotspot.intensity === "medium"
      ? "#eab308"
      : "#22c55e";

  const glowRadius =
    hotspot.intensity === "high"
      ? hotspot.radius * 1.45
      : hotspot.intensity === "medium"
      ? hotspot.radius * 1.28
      : hotspot.radius * 1.18;

  return (
    <>
      <Circle
        pane="territory-vectors"
        center={[hotspot.lat, hotspot.lng]}
        radius={glowRadius}
        pathOptions={{
          color: fillColor,
          weight: 0,
          fillColor,
          fillOpacity: 0.12,
        }}
      />
      <Circle
        pane="territory-vectors"
        center={[hotspot.lat, hotspot.lng]}
        radius={hotspot.radius}
        pathOptions={{
          color: fillColor,
          weight: 1,
          opacity: 0.35,
          fillColor,
          fillOpacity: 0.2,
        }}
      >
        <Tooltip direction="top" opacity={1}>
          <div className="rounded-full border border-white/10 bg-[#07131fcc] px-3 py-1.5 text-[10px] font-black uppercase tracking-[0.14em] text-white">
            {hotspot.label} · {hotspot.intensity} demand
          </div>
        </Tooltip>
      </Circle>
    </>
  );
}

function MapToggle({
  active,
  label,
  onClick,
}: {
  active: boolean;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-full px-4 py-2 text-[11px] font-black uppercase tracking-[0.18em] transition ${
        active
          ? "bg-cyan-400 text-slate-950"
          : "border border-white/10 bg-white/5 text-white hover:bg-white/10"
      }`}
    >
      {label}
    </button>
  );
}

function TopMetric({
  label,
  value,
  tone,
}: {
  label: string;
  value: string;
  tone: "cyan" | "teal" | "amber" | "slate";
}) {
  const toneClass =
    tone === "cyan"
      ? "border-cyan-400/20 bg-cyan-400/10 text-cyan-50"
      : tone === "teal"
      ? "border-teal-400/20 bg-teal-400/10 text-teal-50"
      : tone === "amber"
      ? "border-amber-400/20 bg-amber-400/10 text-amber-50"
      : "border-white/10 bg-white/5 text-white";

  return (
    <div className={`rounded-[18px] border px-3 py-2 ${toneClass}`}>
      <div className="text-[10px] font-black uppercase tracking-[0.22em] opacity-70">
        {label}
      </div>
      <div className="mt-1 truncate text-sm font-black">{value}</div>
    </div>
  );
}

function BottomMetric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-[18px] border border-white/10 bg-white/5 px-3 py-2">
      <div className="text-[10px] font-black uppercase tracking-[0.22em] text-white/50">
        {label}
      </div>
      <div className="mt-1 text-sm font-black text-white">{value}</div>
    </div>
  );
}

function LegendItem({ color, label }: { color: string; label: string }) {
  return (
    <div className="rounded-[18px] border border-white/10 bg-white/5 px-3 py-2">
      <div className="flex items-center gap-2">
        <span
          className="h-3 w-3 rounded-full"
          style={{ backgroundColor: color }}
        />
        <span className="text-[11px] font-black uppercase tracking-[0.16em] text-white/80">
          {label}
        </span>
      </div>
    </div>
  );
}

function geoJsonLineToLatLngs(line: LineString | null): LatLngExpression[] {
  if (!line || !Array.isArray(line.coordinates)) return [];

  return line.coordinates
    .map((point) => {
      if (!Array.isArray(point) || point.length < 2) return null;
      const [lng, lat] = point;
      if (!isFiniteNumber(lat) || !isFiniteNumber(lng)) return null;
      return [lat, lng] as LatLngExpression;
    })
    .filter(Boolean) as LatLngExpression[];
}

function getEstateCenter(estate: EstateRecord): LatLngExpression {
  const point = estateInternalPoint(estate);
  if (point) return [point.lat, point.lng];

  const rings = getEstatePolygonRings(estate);
  if (rings.length && rings[0].length) {
    return centroidOfRing(rings[0]);
  }

  return ISLAND_VIEW[estate.island as IslandCode]?.center ?? [18.336, -64.93];
}

function getEstateBounds(
  estate: EstateRecord | null
): LatLngBoundsExpression | null {
  if (!estate) return null;

  const rings = getEstatePolygonRings(estate);
  if (!rings.length) {
    const center = getEstateCenter(estate);
    return expandPointBounds(center, 0.01);
  }

  const flat = rings.flat();
  if (!flat.length) return null;

  return L.latLngBounds(flat as LatLngExpression[]);
}

function getEstatePolygonRings(estate: EstateRecord): LatLngExpression[][] {
  const candidates: unknown[] = [
    (estate as any).geometry,
    (estate as any).polygon,
    (estate as any).boundary,
    (estate as any).shape,
    (estate as any).geojson,
  ];

  for (const candidate of candidates) {
    const normalized = normalizePolygonCandidate(candidate);
    if (normalized.length) return normalized;
  }

  return [];
}

function normalizePolygonCandidate(value: unknown): LatLngExpression[][] {
  if (!value) return [];

  if (
    typeof value === "object" &&
    value !== null &&
    "type" in value &&
    (value as any).type === "Polygon" &&
    Array.isArray((value as any).coordinates)
  ) {
    return polygonCoordinatesToLeaflet((value as any).coordinates);
  }

  if (
    typeof value === "object" &&
    value !== null &&
    "type" in value &&
    (value as any).type === "Feature" &&
    (value as any).geometry
  ) {
    return normalizePolygonCandidate((value as any).geometry);
  }

  if (
    typeof value === "object" &&
    value !== null &&
    "type" in value &&
    (value as any).type === "MultiPolygon" &&
    Array.isArray((value as any).coordinates)
  ) {
    const firstPolygon = (value as any).coordinates[0];
    return polygonCoordinatesToLeaflet(firstPolygon);
  }

  if (
    typeof value === "object" &&
    value !== null &&
    Array.isArray((value as any).coordinates)
  ) {
    return polygonCoordinatesToLeaflet((value as any).coordinates);
  }

  if (Array.isArray(value)) {
    return polygonCoordinatesToLeaflet(value);
  }

  return [];
}

function polygonCoordinatesToLeaflet(coords: unknown): LatLngExpression[][] {
  if (!Array.isArray(coords)) return [];

  if (
    coords.length &&
    Array.isArray(coords[0]) &&
    Array.isArray((coords[0] as any)[0]) &&
    typeof (coords[0] as any)[0][0] === "number"
  ) {
    return (coords as Position[][])
      .map(
        (ring) =>
          ring
            .map((point) => {
              if (!Array.isArray(point) || point.length < 2) return null;
              const [lng, lat] = point;
              if (!isFiniteNumber(lat) || !isFiniteNumber(lng)) return null;
              return [lat, lng] as LatLngExpression;
            })
            .filter(Boolean) as LatLngExpression[]
      )
      .filter((ring) => ring.length >= 3);
  }

  if (
    coords.length &&
    Array.isArray(coords[0]) &&
    Array.isArray((coords[0] as any)[0]) &&
    Array.isArray((coords[0] as any)[0][0])
  ) {
    return polygonCoordinatesToLeaflet((coords as any[])[0]);
  }

  return [];
}

function centroidOfRing(ring: LatLngExpression[]): LatLngExpression {
  if (!ring.length) return [18.336, -64.93];

  const total = ring.reduce<{ lat: number; lng: number }>(
    (acc, point) => {
      const [lat, lng] = toLatLngTuple(point);
      acc.lat += lat;
      acc.lng += lng;
      return acc;
    },
    { lat: 0, lng: 0 }
  );

  return [total.lat / ring.length, total.lng / ring.length];
}

function estateInternalPoint(
  estate: EstateRecord
): { lat: number; lng: number } | null {
  const point = (estate as any).internalPoint;
  if (point && isFiniteNumber(point.lat) && isFiniteNumber(point.lng)) {
    return { lat: point.lat, lng: point.lng };
  }

  if (
    isFiniteNumber((estate as any).lat) &&
    isFiniteNumber((estate as any).lng)
  ) {
    return { lat: (estate as any).lat, lng: (estate as any).lng };
  }

  return null;
}

function buildSyntheticDrivers(
  estates: EstateRecord[],
  island: IslandCode
): DriverMarker[] {
  const pool = estates.slice(0, 9);

  return pool.map((estate, index) => {
    const center = toLatLngTuple(getEstateCenter(estate));
    const latOffset = ((index % 3) - 1) * 0.0038;
    const lngOffset = ((index % 4) - 1.5) * 0.0042;

    return {
      id: `${island}-driver-${estate.geoid}-${index}`,
      label: `Driver ${index + 1}`,
      lat: center[0] + latOffset,
      lng: center[1] + lngOffset,
      status:
        index % 3 === 0
          ? "available"
          : index % 3 === 1
          ? "assigned"
          : "repositioning",
      nearEstate: estate.baseName,
    };
  });
}

function buildDemandHotspots(
  estates: EstateRecord[],
  places: PlaceRecord[],
  island: IslandCode
): DemandHotspot[] {
  const fromPlaces = places.slice(0, 5).map((place, index) => ({
    id: `${island}-place-hotspot-${index}`,
    label: place.name || place.title || `Zone ${index + 1}`,
    lat: place.lat as number,
    lng: place.lng as number,
    radius: index % 3 === 0 ? 520 : index % 3 === 1 ? 700 : 920,
    intensity:
      index % 3 === 0
        ? ("high" as const)
        : index % 3 === 1
        ? ("medium" as const)
        : ("low" as const),
  }));

  if (fromPlaces.length) return fromPlaces;

  return estates.slice(0, 4).map((estate, index) => {
    const center = toLatLngTuple(getEstateCenter(estate));
    return {
      id: `${island}-estate-hotspot-${estate.geoid}`,
      label: estate.baseName,
      lat: center[0],
      lng: center[1],
      radius: index % 2 === 0 ? 760 : 560,
      intensity: index % 2 === 0 ? "medium" : "high",
    };
  });
}

function lensLabel(lens: Lens): string {
  if (lens === "beaches") return "Beaches";
  if (lens === "stays") return "Stays";
  if (lens === "historic") return "Historic";
  if (lens === "drivers") return "Drivers";
  if (lens === "demand") return "Demand";
  return "Places";
}

function savePlaceToTrip(place: PlaceRecord) {
  if (typeof window === "undefined") return;
  const key = "vi-guide.saved-places";
  const existing = JSON.parse(window.localStorage.getItem(key) || "[]") as PlaceRecord[];
  const identity = place.id || `${place.name || place.title}-${place.lat}-${place.lng}`;
  const next = existing.some((item) => (item.id || `${item.name || item.title}-${item.lat}-${item.lng}`) === identity)
    ? existing
    : [...existing, place];
  window.localStorage.setItem(key, JSON.stringify(next));
  window.dispatchEvent(new CustomEvent("vi-guide:place-saved", { detail: place }));
}

function placeColor(category: string): string {
  const key = category.toLowerCase();

  if (key.includes("beach")) return "#38bdf8";
  if (key.includes("hotel") || key.includes("stay") || key.includes("villa")) {
    return "#a78bfa";
  }
  if (
    key.includes("historic") ||
    key.includes("museum") ||
    key.includes("fort")
  ) {
    return "#f59e0b";
  }
  if (key.includes("restaurant") || key.includes("food")) return "#ef4444";
  return "#e2e8f0";
}

function makePinIcon(color: string, letter: string): L.DivIcon {
  return L.divIcon({
    className: "",
    html: `
      <div style="
        width: 30px;
        height: 30px;
        border-radius: 999px;
        background: ${color};
        color: white;
        display:flex;
        align-items:center;
        justify-content:center;
        font-weight: 900;
        font-size: 12px;
        border: 2px solid rgba(255,255,255,0.9);
        box-shadow: 0 8px 22px rgba(0,0,0,0.35);
      ">
        ${letter}
      </div>
    `,
    iconSize: [30, 30],
    iconAnchor: [15, 15],
  });
}

function makeDriverIcon(color: string): L.DivIcon {
  return L.divIcon({
    className: "",
    html: `
      <div style="
        width: 18px;
        height: 18px;
        border-radius: 999px;
        background: ${color};
        border: 2px solid white;
        box-shadow: 0 8px 20px rgba(0,0,0,0.35);
      "></div>
    `,
    iconSize: [18, 18],
    iconAnchor: [9, 9],
  });
}

function isFiniteNumber(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}

function toLatLngTuple(value: LatLngExpression): [number, number] {
  if (Array.isArray(value)) {
    return [value[0], value[1]];
  }

  if (value && typeof value === "object") {
    const maybePoint = value as { lat?: unknown; lng?: unknown };

    if (
      typeof maybePoint.lat === "number" &&
      typeof maybePoint.lng === "number"
    ) {
      return [maybePoint.lat, maybePoint.lng];
    }
  }

  return [18.336, -64.93];
}

function expandPointBounds(
  center: LatLngExpression,
  delta = 0.01
): LatLngBoundsExpression {
  const [lat, lng] = toLatLngTuple(center);

  return [
    [lat - delta, lng - delta],
    [lat + delta, lng + delta],
  ];
}
