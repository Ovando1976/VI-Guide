import type { EstateRecord, ManifestPlace } from "@/types/usvi";
import type { TerritoryEntity, TerritoryEntityKind } from "@/types/territory";

export type TravelKnowledgeRecord = {
  id: string;
  slug?: string;
  name: string;
  island: "stt" | "stj" | "stx";
  category?: string;
  description?: string;
  shortDescription?: string;
  heroImage?: string;
  images?: string[];
  tags?: string[];
  featured?: boolean;
  rating?: number;
  lat?: number;
  lng?: number;
  location?: string;
  bestFor?: string[];
  [key: string]: unknown;
};

export function estateToTerritoryEntity(estate: EstateRecord): TerritoryEntity {
  return {
    id: `estate:${estate.geoid}`,
    slug: estate.geoid,
    kind: "estate",
    island: estate.island,
    title: estate.baseName,
    summary: estate.description.short ?? undefined,
    description: estate.description.long ?? undefined,
    position: estate.internalPoint,
    geometry: estate.geometry ?? null,
    estateGeoid: estate.geoid,
    categories: ["estate"],
    tags: [estate.county, estate.estateCode].filter(Boolean),
    status: "active",
    attributes: {
      geoid: estate.geoid,
      fullName: estate.fullName,
      county: estate.county,
      roadContext: estate.roadContext,
      descriptionSource: estate.description.source,
    },
    actions: [
      { id: "explore", label: "Explore estate", intent: "open" },
      { id: "pickup", label: "Set pickup", intent: "ride" },
      { id: "destination", label: "Set destination", intent: "directions" },
    ],
    source: {
      provider: estate.description.source ?? "territory-estate-registry",
      sourceId: estate.geoid,
      verified: true,
    },
  };
}

export function manifestPlaceToTerritoryEntity(place: ManifestPlace): TerritoryEntity {
  const kind = manifestCategoryToKind(place.category);
  return {
    id: `place:${place.id}`,
    slug: place.id,
    kind,
    island: place.island,
    title: place.name,
    summary: place.description,
    description: place.description,
    position: { lat: place.lat, lng: place.lng },
    categories: [place.category.toLowerCase()],
    tags: [place.location, place.featured ? "featured" : ""].filter(Boolean),
    status: "active",
    rating: place.rating,
    media: { hero: place.image },
    attributes: {
      location: place.location,
      featured: Boolean(place.featured),
      legacyCategory: place.category,
    },
    actions: defaultPlaceActions(place.id),
    source: { provider: "vi-guide-manifest", sourceId: place.id, verified: true },
  };
}

export function travelKnowledgeToTerritoryEntity(
  record: TravelKnowledgeRecord,
  kindOverride?: TerritoryEntityKind,
): TerritoryEntity {
  const category = String(record.category ?? kindOverride ?? "place").toLowerCase();
  const kind = kindOverride ?? categoryToKind(category);
  const excluded = new Set([
    "id", "slug", "name", "island", "category", "description",
    "shortDescription", "heroImage", "images", "tags", "featured",
    "rating", "lat", "lng", "location",
  ]);
  const attributes = Object.fromEntries(
    Object.entries(record).filter(([key]) => !excluded.has(key)),
  );

  return {
    id: `${kind}:${record.id}`,
    slug: record.slug ?? record.id,
    kind,
    island: record.island,
    title: record.name,
    summary: record.shortDescription ?? record.description,
    description: record.description ?? record.shortDescription,
    position:
      typeof record.lat === "number" && typeof record.lng === "number"
        ? { lat: record.lat, lng: record.lng }
        : undefined,
    categories: [...new Set([category, kind])],
    tags: [...new Set(record.tags ?? [])],
    status: "active",
    rating: record.rating,
    media: { hero: record.heroImage, images: record.images },
    attributes: {
      ...attributes,
      location: record.location,
      featured: Boolean(record.featured),
    },
    actions: defaultPlaceActions(record.slug ?? record.id),
    source: { provider: "vi-guide-travel-knowledge", sourceId: record.id },
  };
}

export function territoryEntityToMapPlace(entity: TerritoryEntity) {
  return {
    id: entity.id,
    name: entity.title,
    island: entity.island,
    lat: entity.position?.lat,
    lng: entity.position?.lng,
    category: entity.kind,
    type: entity.categories[0],
    location:
      typeof entity.attributes.location === "string"
        ? entity.attributes.location
        : undefined,
    description: entity.summary ?? entity.description,
    rating: entity.rating,
    image: entity.media?.hero,
  };
}

function manifestCategoryToKind(category: ManifestPlace["category"]): TerritoryEntityKind {
  if (category === "Beach") return "beach";
  if (category === "Hotel") return "stay";
  if (category === "Transit") return "transport";
  return "historic";
}

function categoryToKind(category: string): TerritoryEntityKind {
  if (category.includes("beach")) return "beach";
  if (category.includes("historic") || category.includes("landmark")) return "historic";
  if (category.includes("hotel") || category.includes("stay") || category.includes("villa")) return "stay";
  if (category.includes("ferry") || category.includes("taxi") || category.includes("transit")) return "transport";
  if (category.includes("event")) return "event";
  if (category.includes("service")) return "service";
  return "place";
}

function defaultPlaceActions(slug: string) {
  return [
    { id: "open", label: "Explore", href: `/places/${slug}`, intent: "open" as const },
    { id: "directions", label: "Directions", intent: "directions" as const },
    { id: "save", label: "Add to trip", intent: "save" as const },
    { id: "concierge", label: "Ask Concierge", intent: "concierge" as const },
  ];
}
