"use client";

import dynamic from "next/dynamic";
import { useRouter, useSearchParams } from "next/navigation";
import { useCallback, useEffect, useMemo, useState } from "react";
import type { LineString } from "geojson";

import { ViConcierge } from "@/components/concierge/vi-concierge";
import type { ConciergeContext } from "@/types/concierge";

import { ExplorerCommandHeader } from "@/components/explorer/explorer-command-header";
import { MobilityActionDock } from "@/components/explorer/mobility-action-dock";
import { TerritoryIntelligenceRail } from "@/components/explorer/territory-intelligence-rail";
import { TerritoryKpiBar } from "@/components/explorer/territory-kpi-bar";
import { TerritoryMapWorkspace } from "@/components/explorer/territory-map-workspace";
import { DEMO_PLACES, ISLAND_META, searchEstates } from "@/lib/usvi";
import type { RideMode } from "@/types/mobility";
import type { EstateRecord, IslandCode } from "@/types/usvi";

const EstateMap = dynamic(
  () => import("@/components/estate-map").then((module) => module.EstateMap),
  {
    ssr: false,
    loading: () => (
      <div className="min-h-[500px] w-full animate-pulse rounded-2xl border border-white/10 bg-white/[0.04] md:min-h-[620px]" />
    ),
  }
);

type Lens = "beaches" | "places" | "stays" | "historic" | "drivers" | "demand";
type MapMode = "arrival" | "stay" | "discovery";
type RouteStatus = "idle" | "loading" | "ready" | "error";
type RouteMetrics = { distanceMeters: number; durationSeconds: number };

const DEFAULT_ESTATE_BY_ISLAND: Record<IslandCode, string[]> = {
  stt: ["kings quarter", "charlotte amalie", "bovoni", "airport"],
  stj: ["cruz bay", "enighed", "carolina"],
  stx: ["christiansted", "frederiksted", "kings quarter"],
};

const QUICK_ROUTE_PRESETS: Record<
  string,
  { island: IslandCode; mode: RideMode; fromMatch: string[]; toMatch: string[] }
> = {
  "Airport transfer": {
    island: "stt",
    mode: "airport",
    fromMatch: ["airport", "cyril e king"],
    toMatch: ["charlotte amalie", "red hook", "bovoni"],
  },
  "Red Hook ferry": {
    island: "stt",
    mode: "ferry-transfer",
    fromMatch: ["red hook"],
    toMatch: ["charlotte amalie", "bovoni"],
  },
  "Charlotte Amalie": {
    island: "stt",
    mode: "standard",
    fromMatch: ["charlotte amalie"],
    toMatch: ["bovoni", "red hook"],
  },
  "Cruz Bay run": {
    island: "stj",
    mode: "standard",
    fromMatch: ["cruz bay"],
    toMatch: ["carolina", "enighed"],
  },
  "Safari ride": {
    island: "stt",
    mode: "shared",
    fromMatch: ["charlotte amalie", "bovoni"],
    toMatch: ["red hook", "kings quarter"],
  },
  "Resort pickup": {
    island: "stt",
    mode: "premium",
    fromMatch: ["bovoni", "red hook"],
    toMatch: ["charlotte amalie", "airport"],
  },
};

const ISLAND_SPOTLIGHT: Record<
  IslandCode,
  { title: string; focus: string; route: string; tags: string[] }
> = {
  stt: {
    title: "St. Thomas",
    focus: "Airport, harbor, resorts, town, and hillside access",
    route: "Cyril E. King → Charlotte Amalie → Red Hook",
    tags: ["harbor-linked", "resort corridor", "east-end connector"],
  },
  stj: {
    title: "St. John",
    focus: "Ferry arrivals, villas, beaches, and Cruz Bay",
    route: "Cruz Bay → North Shore → villa pickup",
    tags: ["ferry-first", "beach corridor", "villa access"],
  },
  stx: {
    title: "St. Croix",
    focus: "Airport, Christiansted, Frederiksted, and cross-island corridors",
    route: "Airport → Christiansted → west end transfer",
    tags: ["territory-scale", "historic estates", "cross-island movement"],
  },
};

const QUICK_ROUTE_ORDER: Record<MapMode, string[]> = {
  arrival: [
    "Airport transfer",
    "Red Hook ferry",
    "Charlotte Amalie",
    "Resort pickup",
    "Safari ride",
    "Cruz Bay run",
  ],
  stay: [
    "Resort pickup",
    "Charlotte Amalie",
    "Red Hook ferry",
    "Airport transfer",
    "Safari ride",
    "Cruz Bay run",
  ],
  discovery: [
    "Charlotte Amalie",
    "Red Hook ferry",
    "Cruz Bay run",
    "Safari ride",
    "Resort pickup",
    "Airport transfer",
  ],
};

const LENS_ORDER: Record<MapMode, Lens[]> = {
  arrival: ["drivers", "places", "stays", "demand", "beaches", "historic"],
  stay: ["stays", "places", "beaches", "historic", "drivers", "demand"],
  discovery: ["places", "beaches", "historic", "stays", "drivers", "demand"],
};

function modeDefaults(mode: MapMode): { lens: Lens; rideMode: RideMode } {
  if (mode === "arrival") return { lens: "drivers", rideMode: "airport" };
  if (mode === "stay") return { lens: "stays", rideMode: "premium" };
  return { lens: "places", rideMode: "standard" };
}

function validMode(value: string | null): MapMode {
  return value === "arrival" || value === "stay" ? value : "discovery";
}

function validIsland(value: string | null): IslandCode | null {
  const normalized = value?.trim().toLowerCase();
  return normalized === "stt" || normalized === "stj" || normalized === "stx"
    ? normalized
    : null;
}

function findEstateByMatchers(estates: EstateRecord[], matchers: string[]) {
  const searchable = estates.map((estate) => ({
    estate,
    text: `${estate.baseName} ${estate.fullName} ${
      estate.estateCode ?? ""
    }`.toLowerCase(),
  }));
  for (const matcher of matchers) {
    const match = searchable.find((item) =>
      item.text.includes(matcher.toLowerCase())
    );
    if (match) return match.estate;
  }
  return null;
}

function inferEstateTags(estate: EstateRecord | null, island: IslandCode) {
  if (!estate) return ISLAND_SPOTLIGHT[island].tags;
  const text = `${estate.baseName} ${estate.fullName}`.toLowerCase();
  const tags = new Set<string>();
  if (/bay|harbor|hook|amalie/.test(text)) tags.add("harbor-linked");
  if (/airport|king|terminal/.test(text)) tags.add("airport-adjacent");
  if (/east|red hook|smith|nazareth/.test(text)) tags.add("east-end connector");
  if (/mount|hill|ridge|heights/.test(text)) tags.add("hillside access");
  if (/cruz|enighed|carolina/.test(text)) tags.add("ferry-first");
  if (/christiansted|frederiksted|company|prince/.test(text))
    tags.add("historic corridor");
  if (!tags.size) ISLAND_SPOTLIGHT[island].tags.forEach((tag) => tags.add(tag));
  return [...tags];
}

function squaredDistance(a: EstateRecord, b: EstateRecord) {
  const lat = a.internalPoint.lat - b.internalPoint.lat;
  const lng = a.internalPoint.lng - b.internalPoint.lng;
  return lat * lat + lng * lng;
}

export function ExplorerMapScreen() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [estates, setEstates] = useState<EstateRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [reloadNonce, setReloadNonce] = useState(0);

  const [island, setIsland] = useState<IslandCode>("stt");
  const [query, setQuery] = useState("");
  const [selectedEstateGeoid, setSelectedEstateGeoid] = useState<string | null>(
    null
  );
  const [fromGeoid, setFromGeoid] = useState("");
  const [toGeoid, setToGeoid] = useState("");
  const [mode, setMode] = useState<RideMode>("standard");
  const [modeContext, setModeContext] = useState<MapMode>("discovery");
  const [activeLens, setActiveLens] = useState<Lens>("places");
  const [passengers, setPassengers] = useState(1);
  const [luggage, setLuggage] = useState(0);
  const [routeGeoJson, setRouteGeoJson] = useState<LineString | null>(null);
  const [routeFocusNonce, setRouteFocusNonce] = useState(0);
  const [routeStatus, setRouteStatus] = useState<RouteStatus>("idle");
  const [routeMessage, setRouteMessage] = useState<string | null>(null);
  const [routeMetrics, setRouteMetrics] = useState<RouteMetrics | null>(null);

  const handleChangeIsland = useCallback((nextIsland: IslandCode) => {
    setIsland(nextIsland);
    setQuery("");
    setSelectedEstateGeoid(null);
    setFromGeoid("");
    setToGeoid("");
    setRouteGeoJson(null);
    setRouteStatus("idle");
    setRouteMessage(null);
    setRouteMetrics(null);
    window.localStorage.setItem("vi-guide.active-island", nextIsland);
  }, []);

  const handleSelectFrom = useCallback(
    (geoid: string) => {
      setFromGeoid(geoid);
      if (geoid && geoid === toGeoid) setToGeoid("");
    },
    [toGeoid]
  );

  const handleSelectTo = useCallback(
    (geoid: string) => {
      setToGeoid(geoid);
      if (geoid && geoid === fromGeoid) setFromGeoid("");
    },
    [fromGeoid]
  );

  useEffect(() => {
    const controller = new AbortController();
    async function loadEstates() {
      try {
        setLoading(true);
        setLoadError(null);
        const response = await fetch("/api/estates", {
          cache: "no-store",
          signal: controller.signal,
        });
        const payload = await response.json().catch(() => null);
        if (!response.ok)
          throw new Error(payload?.error ?? "Failed to load estates.");
        const loaded = Array.isArray(payload?.estates) ? payload.estates : [];
        setEstates(loaded);
        if (!loaded.length)
          setLoadError("No estate records were returned from the API.");
      } catch (error) {
        if (controller.signal.aborted) return;
        setLoadError(
          error instanceof Error ? error.message : "Failed to load estates."
        );
      } finally {
        if (!controller.signal.aborted) setLoading(false);
      }
    }
    loadEstates();
    return () => controller.abort();
  }, [reloadNonce]);

  useEffect(() => {
    const context = validMode(searchParams.get("mode"));
    const defaults = modeDefaults(context);
    setModeContext(context);
    setMode(defaults.rideMode);
    setActiveLens(defaults.lens);
    const requestedIsland = validIsland(searchParams.get("island"));
    const rememberedIsland = validIsland(
      window.localStorage.getItem("vi-guide.active-island"),
    );
    const nextIsland = requestedIsland ?? rememberedIsland;
    if (nextIsland) setIsland(nextIsland);
  }, [searchParams]);

  useEffect(() => {
    window.localStorage.setItem("vi-guide.active-island", island);
  }, [island]);

  useEffect(() => {
    window.localStorage.setItem(
      "vi-guide.trip-draft",
      JSON.stringify({
        island,
        from: fromGeoid,
        to: toGeoid,
        mode,
        passengers,
        luggage,
      }),
    );
  }, [island, fromGeoid, toGeoid, mode, passengers, luggage]);

  useEffect(() => {
    const requestedEstate = searchParams.get("estate");
    if (!requestedEstate || !estates.length) return;
    const match = estates.find((estate) => estate.geoid === requestedEstate);
    if (!match) return;
    setIsland(match.island);
    setSelectedEstateGeoid(match.geoid);
    if (modeContext === "stay") setFromGeoid(match.geoid);
  }, [searchParams, estates, modeContext]);

  const islandEstates = useMemo(
    () => estates.filter((estate) => estate.island === island),
    [estates, island]
  );
  const filteredEstates = useMemo(
    () => searchEstates(estates, query, island),
    [estates, query, island]
  );

  useEffect(() => {
    if (!islandEstates.length) return;

    const selectedIsValid = islandEstates.some(
      (estate) => estate.geoid === selectedEstateGeoid
    );

    // Discovery and arrival open at island scale. An estate only becomes the
    // active focus after the traveler explicitly selects it (or via a URL).
    if (!selectedIsValid && selectedEstateGeoid) {
      setSelectedEstateGeoid(null);
    }

    if (modeContext === "stay" && !fromGeoid) {
      const fallback =
        findEstateByMatchers(islandEstates, DEFAULT_ESTATE_BY_ISLAND[island]) ??
        islandEstates[0];
      setFromGeoid(fallback.geoid);
    }

    if (modeContext === "arrival" && !fromGeoid) {
      const airport = findEstateByMatchers(islandEstates, [
        "airport",
        "cyril e king",
        "rohlsen",
      ]);
      if (airport) setFromGeoid(airport.geoid);
    }
  }, [islandEstates, selectedEstateGeoid, island, modeContext, fromGeoid]);

  const selectedEstate =
    estates.find((estate) => estate.geoid === selectedEstateGeoid) ?? null;
  const fromEstate =
    islandEstates.find((estate) => estate.geoid === fromGeoid) ?? null;
  const toEstate =
    islandEstates.find((estate) => estate.geoid === toGeoid) ?? null;

  const allIslandPlaces = useMemo(
    () => DEMO_PLACES.filter((place) => place.island === island),
    [island]
  );
  const islandPlaces = useMemo(() => {
    if (activeLens === "beaches")
      return allIslandPlaces.filter((place) => place.category === "Beach");
    if (activeLens === "stays")
      return allIslandPlaces.filter((place) => place.category === "Hotel");
    if (activeLens === "historic")
      return allIslandPlaces.filter((place) => place.category === "Landmark");
    return allIslandPlaces;
  }, [allIslandPlaces, activeLens]);

  const neighboringEstates = useMemo(() => {
    if (!selectedEstate) return [];
    return islandEstates
      .filter((estate) => estate.geoid !== selectedEstate.geoid)
      .sort(
        (a, b) =>
          squaredDistance(selectedEstate, a) -
          squaredDistance(selectedEstate, b)
      )
      .slice(0, 5);
  }, [islandEstates, selectedEstate]);

  useEffect(() => {
    if (!fromEstate || !toEstate) {
      setRouteGeoJson(null);
      setRouteStatus("idle");
      setRouteMessage(null);
      setRouteMetrics(null);
      return;
    }

    const controller = new AbortController();
    const routeFrom = fromEstate.internalPoint;
    const routeTo = toEstate.internalPoint;
    async function loadRoute() {
      try {
        setRouteStatus("loading");
        setRouteMessage("Calculating the roadway route");
        const response = await fetch("/api/route", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          signal: controller.signal,
          body: JSON.stringify({
            from: routeFrom,
            to: routeTo,
          }),
        });
        const payload = await response.json().catch(() => null);
        if (!response.ok)
          throw new Error(payload?.error ?? "Roadway route unavailable.");
        if (
          payload?.geometry?.type !== "LineString" ||
          !Array.isArray(payload.geometry.coordinates)
        ) {
          throw new Error("The routing provider returned an invalid route.");
        }
        setRouteGeoJson(payload.geometry as LineString);
        setRouteMetrics({
          distanceMeters:
            typeof payload.distanceMeters === "number"
              ? payload.distanceMeters
              : 0,
          durationSeconds:
            typeof payload.durationSeconds === "number"
              ? payload.durationSeconds
              : 0,
        });
        setRouteStatus("ready");
        setRouteMessage("Roadway route ready");
        setRouteFocusNonce((value) => value + 1);
      } catch (error) {
        if (controller.signal.aborted) return;
        setRouteGeoJson(null);
        setRouteMetrics(null);
        setRouteStatus("error");
        setRouteMessage(
          error instanceof Error ? error.message : "Roadway route unavailable."
        );
      }
    }
    loadRoute();
    return () => controller.abort();
  }, [fromEstate, toEstate]);

  function applyQuickRoute(label: string) {
    const preset = QUICK_ROUTE_PRESETS[label];
    if (!preset) return;
    const pool = estates.filter((estate) => estate.island === preset.island);
    const origin = findEstateByMatchers(pool, preset.fromMatch);
    const destination = findEstateByMatchers(pool, preset.toMatch);
    setIsland(preset.island);
    setQuery("");
    setMode(preset.mode);
    setFromGeoid(origin?.geoid ?? "");
    setToGeoid(destination?.geoid ?? "");
    setSelectedEstateGeoid(
      origin?.geoid ?? destination?.geoid ?? pool[0]?.geoid ?? null
    );
    requestAnimationFrame(() => {
      document
        .getElementById("territory-workspace")
        ?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }

  function continueToBooking() {
    if (!fromEstate || !toEstate || fromEstate.geoid === toEstate.geoid) return;
    const params = new URLSearchParams({
      island,
      from: fromEstate.geoid,
      to: toEstate.geoid,
      mode,
      passengers: String(passengers),
      luggage: String(luggage),
    });
    router.push(`/mobility?${params.toString()}`);
  }

  const hero = ISLAND_META[island];
  const spotlight = ISLAND_SPOTLIGHT[island];
  const routeReady = Boolean(
    fromEstate && toEstate && fromEstate.geoid !== toEstate.geoid
  );
  const flowState = routeReady
    ? `${fromEstate?.baseName} → ${toEstate?.baseName}`
    : fromEstate
    ? `Pickup: ${fromEstate.baseName}`
    : selectedEstate
    ? `Focused on ${selectedEstate.baseName}`
    : "Choose an estate";

  const conciergeContext = useMemo<ConciergeContext>(
    () => ({
      island,
      islandName: hero.name,
      selectedEstate: selectedEstate
        ? {
            geoid: selectedEstate.geoid,
            name: selectedEstate.baseName,
          }
        : null,
      pickup: fromEstate
        ? {
            geoid: fromEstate.geoid,
            name: fromEstate.baseName,
          }
        : null,
      destination: toEstate
        ? {
            geoid: toEstate.geoid,
            name: toEstate.baseName,
          }
        : null,
      rideMode: mode,
      passengers,
      luggage,
      activeLens,
      nearbyEstates: neighboringEstates.map((estate) => ({
        geoid: estate.geoid,
        name: estate.baseName,
      })),
    }),
    [
      island,
      hero.name,
      selectedEstate,
      fromEstate,
      toEstate,
      mode,
      passengers,
      luggage,
      activeLens,
      neighboringEstates,
    ]
  );

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top_right,rgba(14,116,144,0.12),transparent_30%),linear-gradient(180deg,#041018_0%,#07131a_45%,#09161f_100%)] text-white">
      <ExplorerCommandHeader
        island={island}
        onChangeIsland={handleChangeIsland}
        query={query}
        onChangeQuery={setQuery}
        heroName={hero.name}
        flowState={flowState}
        quickRoutes={QUICK_ROUTE_ORDER[modeContext]}
        onApplyQuickRoute={applyQuickRoute}
        mode={modeContext}
      />

      <main className="mx-auto max-w-[1800px] space-y-3 px-3 pb-24 pt-3 md:px-6 md:pb-28 md:pt-4">
        {loading ? (
          <LoadingState />
        ) : loadError ? (
          <ErrorState
            message={loadError}
            onRetry={() => setReloadNonce((value) => value + 1)}
          />
        ) : (
          <>
            <TerritoryKpiBar
              islandName={hero.name}
              visibleEstates={filteredEstates.length}
              selectedEstate={selectedEstate?.baseName ?? "None"}
              pickup={fromEstate?.baseName ?? "Not set"}
              destination={toEstate?.baseName ?? "Not set"}
              mode={mode}
              passengers={passengers}
              luggage={luggage}
            />

            <section
              id="territory-workspace"
              className="scroll-mt-40 grid gap-4 xl:grid-cols-[minmax(0,1.75fr)_390px]"
            >
              <TerritoryMapWorkspace
                activeLens={activeLens}
                onChangeLens={setActiveLens}
                lensOrder={LENS_ORDER[modeContext]}
                manifestCount={filteredEstates.length}
                estates={filteredEstates}
                selectedEstateGeoid={selectedEstateGeoid}
                fromGeoid={fromGeoid}
                toGeoid={toGeoid}
                onSelectEstate={setSelectedEstateGeoid}
                onSelectFrom={handleSelectFrom}
                onSelectTo={handleSelectTo}
                routeStatus={routeStatus}
                routeMessage={routeMessage}
                manifestAction={(estate) => (
                  <>
                    <button
                      type="button"
                      disabled={toGeoid === estate.geoid}
                      onClick={() => {
                        handleSelectFrom(estate.geoid);
                        setSelectedEstateGeoid(estate.geoid);
                      }}
                      className="rounded-full border border-white/10 px-3 py-1.5 text-[10px] font-bold text-white/65 transition hover:bg-white/10 hover:text-white disabled:opacity-35"
                    >
                      Pickup
                    </button>
                    <button
                      type="button"
                      disabled={fromGeoid === estate.geoid}
                      onClick={() => {
                        handleSelectTo(estate.geoid);
                        setSelectedEstateGeoid(estate.geoid);
                      }}
                      className="rounded-full border border-white/10 px-3 py-1.5 text-[10px] font-bold text-white/65 transition hover:bg-white/10 hover:text-white disabled:opacity-35"
                    >
                      Destination
                    </button>
                  </>
                )}
              >
                <EstateMap
                  island={island}
                  estates={filteredEstates}
                  places={islandPlaces}
                  activeLens={activeLens}
                  selectedEstateGeoid={selectedEstateGeoid}
                  fromGeoid={fromGeoid}
                  toGeoid={toGeoid}
                  routeGeoJson={routeGeoJson}
                  routeFocusNonce={routeFocusNonce}
                  onSelectEstate={(estate: EstateRecord | null) =>
                    setSelectedEstateGeoid(estate?.geoid ?? null)
                  }
                  onSelectFrom={handleSelectFrom}
                  onSelectTo={handleSelectTo}
                />
              </TerritoryMapWorkspace>

              <TerritoryIntelligenceRail
                islandTitle={spotlight.title}
                islandFocus={spotlight.focus}
                signatureRoute={spotlight.route}
                selectedEstate={selectedEstate}
                fromEstate={fromEstate}
                toEstate={toEstate}
                estateTags={inferEstateTags(selectedEstate, island)}
                neighboringEstates={neighboringEstates}
                onSelectNeighbor={setSelectedEstateGeoid}
                onUseAsPickup={handleSelectFrom}
                onUseAsDestination={handleSelectTo}
                routeReady={routeReady}
              />
            </section>

            <MobilityActionDock
              estates={islandEstates}
              fromGeoid={fromGeoid}
              toGeoid={toGeoid}
              fromEstate={fromEstate}
              toEstate={toEstate}
              mode={mode}
              passengers={passengers}
              luggage={luggage}
              onSelectFrom={handleSelectFrom}
              onSelectTo={handleSelectTo}
              onChangeMode={setMode}
              onChangePassengers={(value) =>
                setPassengers(Math.max(1, Math.min(12, value || 1)))
              }
              onChangeLuggage={(value) =>
                setLuggage(Math.max(0, Math.min(12, value || 0)))
              }
              onSubmit={continueToBooking}
              distanceMeters={routeMetrics?.distanceMeters}
              durationSeconds={routeMetrics?.durationSeconds}
            />
          </>
        )}
      </main>

      <ViConcierge
        context={conciergeContext}
        onSelectEstate={setSelectedEstateGeoid}
        onSetPickup={handleSelectFrom}
        onSetDestination={handleSelectTo}
        placement="right"
        initiallyOpen={searchParams.get("concierge") === "open"}
      />
    </div>
  );
}

function LoadingState() {
  return (
    <div className="grid gap-3" role="status" aria-live="polite">
      <div className="h-16 animate-pulse rounded-2xl bg-white/[0.05]" />
      <div className="min-h-[620px] animate-pulse rounded-[28px] border border-white/10 bg-white/[0.04]" />
      <span className="sr-only">Loading official estate geography</span>
    </div>
  );
}

function ErrorState({
  message,
  onRetry,
}: {
  message: string;
  onRetry: () => void;
}) {
  return (
    <section
      className="rounded-[28px] border border-rose-300/20 bg-rose-300/[0.07] p-6 md:p-8"
      role="alert"
    >
      <div className="text-[10px] font-extrabold uppercase tracking-[0.2em] text-rose-200/70">
        Estate data unavailable
      </div>
      <h2 className="mt-2 text-2xl font-extrabold tracking-tight text-white">
        The map could not load its estate layer.
      </h2>
      <p className="mt-3 max-w-2xl text-sm leading-6 text-rose-50/65">
        {message}
      </p>
      <button
        type="button"
        onClick={onRetry}
        className="mt-5 rounded-xl bg-white px-4 py-2.5 text-xs font-extrabold text-[#10242c] transition hover:bg-rose-50"
      >
        Try again
      </button>
    </section>
  );
}
