import { ExploreExperiencePage } from "@/components/directory/explore-experience-page";
import { getTravelKnowledge } from "@/lib/travel-knowledge";

export default function PlacesPage() {
  return (
    <ExploreExperiencePage
      places={getTravelKnowledge("places")}
      beaches={getTravelKnowledge("beaches")}
      historic={getTravelKnowledge("historic")}
      stays={getTravelKnowledge("stays")}
    />
  );
}
