"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { BedDouble, ClipboardList, Compass, House, Map, Navigation } from "lucide-react";
import clsx from "clsx";

const ITEMS = [
  { href: "/", label: "Home", icon: House },
  { href: "/map", label: "Map", icon: Map },
  { href: "/places", label: "Explore", icon: Compass },
  { href: "/plan", label: "Plan", icon: ClipboardList },
  { href: "/accommodations", label: "Stays", icon: BedDouble },
  { href: "/mobility", label: "Ride", icon: Navigation },
] as const;

export function AppNavigation() {
  const pathname = usePathname();
  if (pathname === "/login" || pathname === "/unauthorized") return null;

  return <nav aria-label="Primary navigation" className="app-nav">
    <div className="app-nav__brand" aria-hidden="true"><span>VI</span></div>
    {ITEMS.map(({ href, label, icon: Icon }) => {
      const active = href === "/" ? pathname === "/" : pathname === href || pathname.startsWith(`${href}/`);
      return <Link key={href} href={href} aria-current={active ? "page" : undefined} className={clsx("app-nav__item", active && "is-active")}>
        <Icon size={18} strokeWidth={2.2} /><span>{label}</span>
      </Link>;
    })}
  </nav>;
}
