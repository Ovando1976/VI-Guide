import fs from "node:fs";
import path from "node:path";

/**
 * Synchronize the public USVI National Register of Historic Places inventory.
 *
 * Sources:
 * - Current NPS National Register listed-properties CSV
 * - NPS Cultural Resources GIS point and polygon services
 *
 * The script deliberately imports only public, unrestricted records. It never
 * invents coordinates. Point locations are used directly; district/site
 * polygons receive a representative interior-ish bbox center and are marked as
 * representative rather than exact.
 *
 * Usage:
 *   npx tsx scripts/sync-usvi-historic-sites.ts
 *   npx tsx scripts/sync-usvi-historic-sites.ts --apply
 */

type IslandCode = "stt" | "stj" | "stx";
type JsonRecord = Record<string, unknown>;

type ExistingHistoricSite = {
  id: string;
  slug?: string;
  name: string;
  island: IslandCode;
  category?: string;
  description?: string;
  shortDescription?: string;
  heroImage?: string;
  images?: string[];
  tags?: string[];
  featured?: boolean;
  imageCount?: number;
  sourceImageIds?: string[];
  createdAt?: string;
  updatedAt?: string;
  [key: string]: unknown;
};

type CoordinateRecord = {
  lat: number;
  lng: number;
  provider: "google-places" | "manual" | "source-data" | "nps-nrhp";
  placeId?: string;
  formattedAddress?: string;
  matchedName?: string;
  confidence: number;
  resolvedAt: string;
  sourceUrl?: string;
  geometryType?: "point" | "polygon-representative";
  coordinateStatus?: "verified" | "representative";
  nrhpReferenceNumber?: string;
};

type CsvRow = Record<string, string>;

type ArcGisFeature = {
  type: "Feature";
  properties: Record<string, unknown>;
  geometry:
    | { type: "Point"; coordinates: [number, number] }
    | { type: "Polygon"; coordinates: number[][][] }
    | { type: "MultiPolygon"; coordinates: number[][][][] }
    | null;
};

type ArcGisCollection = {
  type: "FeatureCollection";
  features: ArcGisFeature[];
};

type OfficialListing = {
  refNumber: string;
  name: string;
  city: string;
  county: string;
  address: string;
  listedDate: string;
  category: string;
  otherNames: string[];
  restricted: boolean;
  externalLink?: string;
};

type SpatialMatch = {
  refNumber: string;
  name: string;
  lat: number;
  lng: number;
  geometryType: "point" | "polygon-representative";
  coordinateStatus: "verified" | "representative";
  boundaryType?: string;
  source?: string;
};

const ROOT = process.cwd();
const APPLY = process.argv.includes("--apply");
const HISTORIC_PATH = path.join(
  ROOT,
  "data/travel-knowledge/historic-sites.json"
);
const COORDINATES_PATH = path.join(ROOT, "data/territory-coordinates.json");
const AUDIT_JSON_PATH = path.join(
  ROOT,
  "data/generated/usvi-historic-sites-audit.json"
);
const AUDIT_MD_PATH = path.join(ROOT, "reports/usvi-historic-sites-audit.md");

const NPS_DATABASE_PAGE =
  "https://www.nps.gov/subjects/nationalregister/database-research.htm";
const NRHP_MAP_SERVICE =
  "https://mapservices.nps.gov/arcgis/rest/services/cultural_resources/nrhp_locations/MapServer";

async function main() {
  const existingSites = readJson<ExistingHistoricSite[]>(HISTORIC_PATH, []);
  const coordinateRegistry = readJson<Record<string, CoordinateRecord>>(
    COORDINATES_PATH,
    {}
  );

  console.log("Discovering the current NPS National Register dataset...");
  const csvUrl = await discoverCurrentCsvUrl();
  console.log(`NPS listings CSV: ${csvUrl}`);

  const [csvText, pointData, polygonData] = await Promise.all([
    fetchText(csvUrl),
    fetchSpatialLayer(0),
    fetchSpatialLayer(1),
  ]);

  const rows = parseCsv(csvText);
  const listings = rows
    .map(toOfficialListing)
    .filter((item): item is OfficialListing => Boolean(item))
    .filter((item) => !item.restricted);

  const spatial = [
    ...extractSpatialMatches(pointData, "point"),
    ...extractSpatialMatches(polygonData, "polygon-representative"),
  ];
  const spatialByRef = new Map<string, SpatialMatch>();

  // Prefer exact point geometry over polygon representative coordinates.
  for (const match of spatial) {
    const previous = spatialByRef.get(match.refNumber);
    if (!previous || previous.geometryType === "polygon-representative") {
      spatialByRef.set(match.refNumber, match);
    }
  }

  const existingByNormalizedName = new Map(
    existingSites.map((site) => [normalize(site.name), site])
  );
  const existingByRef = new Map(
    existingSites
      .map((site) => [String(site.nrhpReferenceNumber ?? ""), site] as const)
      .filter(([ref]) => ref)
  );

  const now = new Date().toISOString();
  const generatedSites: ExistingHistoricSite[] = [];
  const unresolved: Array<{ refNumber: string; name: string; reason: string }> = [];
  let exactPoints = 0;
  let representativePoints = 0;

  for (const listing of listings.sort((a, b) => a.name.localeCompare(b.name))) {
    const spatialMatch = spatialByRef.get(listing.refNumber);
    const island = inferIsland(listing, spatialMatch);

    if (!island) {
      unresolved.push({
        refNumber: listing.refNumber,
        name: listing.name,
        reason: "Could not assign a USVI island from official metadata or geometry",
      });
      continue;
    }

    const prior =
      existingByRef.get(listing.refNumber) ??
      findExistingByName(existingByNormalizedName, listing);
    const slug = prior?.slug ?? slugify(listing.name);
    const id = prior?.id ?? slug;
    const category = inferCategory(listing);
    const aliases = unique([
      ...(Array.isArray(prior?.aliases) ? (prior.aliases as string[]) : []),
      ...listing.otherNames,
    ]).filter((alias) => normalize(alias) !== normalize(listing.name));

    const locationLabel = [listing.address, listing.city]
      .filter(Boolean)
      .join(", ");
    const description =
      prior?.description ??
      `${listing.name} is a public National Register of Historic Places listing in ${islandName(
        island
      )}, U.S. Virgin Islands.`;

    generatedSites.push({
      ...prior,
      id,
      slug,
      name: listing.name,
      aliases,
      island,
      category,
      description,
      shortDescription:
        prior?.shortDescription ??
        `${listing.name} is a federally recognized historic ${category} in ${islandName(
          island
        )}.`,
      heroImage: prior?.heroImage ?? "/images/historic/placeholder.svg",
      images: prior?.images ?? [],
      tags: unique([
        ...(prior?.tags ?? []),
        category,
        island.toUpperCase(),
        "historic",
        "usvi",
        "nrhp",
      ]),
      featured: prior?.featured ?? false,
      imageCount: prior?.imageCount ?? prior?.images?.length ?? 0,
      sourceImageIds: prior?.sourceImageIds ?? [],
      location: locationLabel || prior?.location,
      designation: "National Register of Historic Places",
      nrhpReferenceNumber: listing.refNumber,
      nrhpListedDate: listing.listedDate || undefined,
      nrhpCategory: listing.category || undefined,
      nrhpOtherNames: aliases,
      coordinateStatus: spatialMatch?.coordinateStatus ?? "unresolved",
      coordinateGeometry: spatialMatch?.geometryType,
      sourceUrls: unique(
        [
          listing.externalLink,
          `https://www.nps.gov/subjects/nationalregister/database-research.htm`,
          `${NRHP_MAP_SERVICE}`,
        ].filter((value): value is string => Boolean(value))
      ),
      createdAt: prior?.createdAt ?? now,
      updatedAt: now,
    });

    if (spatialMatch) {
      coordinateRegistry[`${island}:${slug}`] = {
        lat: spatialMatch.lat,
        lng: spatialMatch.lng,
        provider: "nps-nrhp",
        placeId: listing.refNumber,
        formattedAddress: locationLabel || undefined,
        matchedName: listing.name,
        confidence:
          spatialMatch.geometryType === "point" ? 0.96 : 0.86,
        resolvedAt: now,
        sourceUrl: `${NRHP_MAP_SERVICE}/${
          spatialMatch.geometryType === "point" ? 0 : 1
        }`,
        geometryType: spatialMatch.geometryType,
        coordinateStatus: spatialMatch.coordinateStatus,
        nrhpReferenceNumber: listing.refNumber,
      };

      if (spatialMatch.geometryType === "point") exactPoints += 1;
      else representativePoints += 1;
    } else {
      unresolved.push({
        refNumber: listing.refNumber,
        name: listing.name,
        reason: "No public NPS spatial feature was returned",
      });
    }
  }

  // Preserve locally curated, non-NRHP historic records instead of deleting them.
  const officialRefs = new Set(generatedSites.map((site) => site.nrhpReferenceNumber));
  const curatedOnly = existingSites.filter(
    (site) =>
      !site.nrhpReferenceNumber || !officialRefs.has(site.nrhpReferenceNumber)
  );
  const mergedSites = dedupeSites([...generatedSites, ...curatedOnly]).sort(
    (a, b) => a.name.localeCompare(b.name)
  );

  const sortedCoordinates = Object.fromEntries(
    Object.entries(coordinateRegistry).sort(([a], [b]) => a.localeCompare(b))
  );

  const audit = {
    generatedAt: now,
    sources: {
      listingsCsv: csvUrl,
      pointLayer: `${NRHP_MAP_SERVICE}/0`,
      polygonLayer: `${NRHP_MAP_SERVICE}/1`,
    },
    counts: {
      officialPublicListings: listings.length,
      generatedOfficialRecords: generatedSites.length,
      curatedNonNrhpRecordsPreserved: curatedOnly.length,
      totalHistoricRecords: mergedSites.length,
      exactPointCoordinates: exactPoints,
      representativePolygonCoordinates: representativePoints,
      unresolvedOfficialListings: unresolved.length,
    },
    unresolved,
  };

  console.log(JSON.stringify(audit.counts, null, 2));
  console.log(APPLY ? "Mode: APPLY" : "Mode: DRY RUN");

  if (!APPLY) {
    console.log("Run again with --apply to write the catalog and audit files.");
    return;
  }

  ensureParent(HISTORIC_PATH);
  ensureParent(COORDINATES_PATH);
  ensureParent(AUDIT_JSON_PATH);
  ensureParent(AUDIT_MD_PATH);

  writeJson(HISTORIC_PATH, mergedSites);
  writeJson(COORDINATES_PATH, sortedCoordinates);
  writeJson(AUDIT_JSON_PATH, audit);
  fs.writeFileSync(AUDIT_MD_PATH, renderAuditMarkdown(audit), "utf8");

  console.log(`Updated ${path.relative(ROOT, HISTORIC_PATH)}`);
  console.log(`Updated ${path.relative(ROOT, COORDINATES_PATH)}`);
  console.log(`Wrote ${path.relative(ROOT, AUDIT_JSON_PATH)}`);
  console.log(`Wrote ${path.relative(ROOT, AUDIT_MD_PATH)}`);
}

async function discoverCurrentCsvUrl() {
  const html = await fetchText(NPS_DATABASE_PAGE);
  const match = html.match(
    /https:\/\/www\.nps\.gov\/common\/uploads\/sortable_dataset\/nationalregister\/[^"'<>\s]+\.csv(?:\?[^"'<>\s]+)?/i
  );
  if (match) return decodeHtml(match[0]);

  const relative = html.match(
    /\/common\/uploads\/sortable_dataset\/nationalregister\/[^"'<>\s]+\.csv(?:\?[^"'<>\s]+)?/i
  );
  if (relative) return new URL(decodeHtml(relative[0]), NPS_DATABASE_PAGE).href;

  throw new Error("Could not discover the current National Register CSV URL");
}

async function fetchSpatialLayer(layerId: 0 | 1): Promise<ArcGisCollection> {
  const query = new URL(`${NRHP_MAP_SERVICE}/${layerId}/query`);
  query.searchParams.set("where", "State='VI' AND STATUS='Listed'");
  query.searchParams.set("outFields", "*");
  query.searchParams.set("returnGeometry", "true");
  query.searchParams.set("outSR", "4326");
  query.searchParams.set("f", "geojson");
  return fetchJson<ArcGisCollection>(query.href);
}

function extractSpatialMatches(
  collection: ArcGisCollection,
  expectedType: "point" | "polygon-representative"
): SpatialMatch[] {
  const output: SpatialMatch[] = [];
  for (const feature of collection.features ?? []) {
    const refNumber = clean(
      feature.properties.NRIS_Refnum ?? feature.properties.PROPERTY_ID
    );
    if (!refNumber || !feature.geometry) continue;

    let point: { lat: number; lng: number } | null = null;
    let geometryType: SpatialMatch["geometryType"] = expectedType;

    if (feature.geometry.type === "Point") {
      const [lng, lat] = feature.geometry.coordinates;
      point = validLatLng(lat, lng) ? { lat, lng } : null;
      geometryType = "point";
    } else {
      point = representativePoint(feature.geometry);
      geometryType = "polygon-representative";
    }

    if (!point || !insideUsvi(point.lat, point.lng)) continue;

    output.push({
      refNumber,
      name: clean(feature.properties.RESNAME),
      lat: point.lat,
      lng: point.lng,
      geometryType,
      coordinateStatus:
        geometryType === "point" ? "verified" : "representative",
      boundaryType: clean(feature.properties.BND_TYPE),
      source: clean(feature.properties.SOURCE),
    });
  }
  return output;
}

function representativePoint(
  geometry:
    | { type: "Polygon"; coordinates: number[][][] }
    | { type: "MultiPolygon"; coordinates: number[][][][] }
) {
  const pairs: number[][] = [];
  const walk = (value: unknown): void => {
    if (
      Array.isArray(value) &&
      value.length >= 2 &&
      typeof value[0] === "number" &&
      typeof value[1] === "number"
    ) {
      pairs.push(value as number[]);
      return;
    }
    if (Array.isArray(value)) value.forEach(walk);
  };
  walk(geometry.coordinates);
  if (!pairs.length) return null;

  const lngs = pairs.map((pair) => pair[0]);
  const lats = pairs.map((pair) => pair[1]);
  const lng = (Math.min(...lngs) + Math.max(...lngs)) / 2;
  const lat = (Math.min(...lats) + Math.max(...lats)) / 2;
  return validLatLng(lat, lng) ? { lat, lng } : null;
}

function toOfficialListing(row: CsvRow): OfficialListing | null {
  const state = pick(row, "State");
  const status = pick(row, "Status");
  if (state.trim().toUpperCase() !== "VI") return null;
  if (status && !/listed/i.test(status)) return null;

  const refNumber = pick(row, "Ref#", "Reference Number", "Ref Number");
  const name = pick(row, "Property Name", "Resource Name");
  if (!refNumber || !name) return null;

  const restrictedValue = pick(row, "Restricted Address", "Restricted");
  const restricted = /^(yes|true|y|1|restricted)$/i.test(restrictedValue.trim());

  return {
    refNumber,
    name,
    city: pick(row, "City"),
    county: pick(row, "County"),
    address: pick(row, "Street & Number", "Address"),
    listedDate: pick(row, "Listed Date"),
    category: pick(row, "Category of Property", "Resource Type"),
    otherNames: splitAliases(pick(row, "Other Names")),
    restricted,
    externalLink: pick(row, "External Link") || undefined,
  };
}

function inferIsland(
  listing: OfficialListing,
  spatial?: SpatialMatch
): IslandCode | null {
  if (spatial) {
    if (spatial.lat < 18) return "stx";
    if (spatial.lng > -64.84) return "stj";
    return "stt";
  }

  const haystack = normalize(
    [listing.name, listing.city, listing.county, listing.address].join(" ")
  );
  const stxTerms = [
    "christiansted",
    "frederiksted",
    "st-croix",
    "saint-croix",
    "salt-river",
    "coakley-bay",
    "green-kay",
  ];
  const stjTerms = [
    "cruz-bay",
    "coral-bay",
    "st-john",
    "saint-john",
    "reef-bay",
    "cinnamon-bay",
    "brown-bay",
    "dennis-bay",
    "leinster-bay",
    "hurricane-hole",
    "trunk-bay",
  ];
  if (stxTerms.some((term) => haystack.includes(term))) return "stx";
  if (stjTerms.some((term) => haystack.includes(term))) return "stj";
  if (
    haystack.includes("charlotte-amalie") ||
    haystack.includes("st-thomas") ||
    haystack.includes("saint-thomas") ||
    haystack.includes("hassel-island")
  )
    return "stt";
  return null;
}

function inferCategory(listing: OfficialListing) {
  const value = normalize(`${listing.category} ${listing.name}`);
  if (value.includes("historic-district") || value.includes("district"))
    return "district";
  if (value.includes("fort") || value.includes("fortsberg")) return "fort";
  if (value.includes("church") || value.includes("synagogue") || value.includes("mission"))
    return "church";
  if (value.includes("plantation") || value.includes("estate")) return "estate";
  if (value.includes("school")) return "landmark";
  if (value.includes("warehouse")) return "landmark";
  if (value.includes("site")) return "site";
  return "landmark";
}

function findExistingByName(
  index: Map<string, ExistingHistoricSite>,
  listing: OfficialListing
) {
  const direct = index.get(normalize(listing.name));
  if (direct) return direct;
  for (const alias of listing.otherNames) {
    const match = index.get(normalize(alias));
    if (match) return match;
  }
  return undefined;
}

function dedupeSites(sites: ExistingHistoricSite[]) {
  const result = new Map<string, ExistingHistoricSite>();
  for (const site of sites) {
    const ref = String(site.nrhpReferenceNumber ?? "");
    const key = ref ? `nrhp:${ref}` : `${site.island}:${normalize(site.name)}`;
    const previous = result.get(key);
    if (!previous || Number(Boolean(site.nrhpReferenceNumber)) > Number(Boolean(previous.nrhpReferenceNumber))) {
      result.set(key, site);
    }
  }
  return [...result.values()];
}

function parseCsv(text: string): CsvRow[] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let quoted = false;

  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    const next = text[index + 1];
    if (char === '"' && quoted && next === '"') {
      field += '"';
      index += 1;
    } else if (char === '"') {
      quoted = !quoted;
    } else if (char === "," && !quoted) {
      row.push(field);
      field = "";
    } else if ((char === "\n" || char === "\r") && !quoted) {
      if (char === "\r" && next === "\n") index += 1;
      row.push(field);
      field = "";
      if (row.some((value) => value.length > 0)) rows.push(row);
      row = [];
    } else {
      field += char;
    }
  }
  if (field || row.length) {
    row.push(field);
    rows.push(row);
  }

  const headers = (rows.shift() ?? []).map((header) => header.replace(/^\uFEFF/, "").trim());
  return rows.map((values) =>
    Object.fromEntries(headers.map((header, index) => [header, values[index]?.trim() ?? ""]))
  );
}

function renderAuditMarkdown(audit: {
  generatedAt: string;
  sources: Record<string, string>;
  counts: Record<string, number>;
  unresolved: Array<{ refNumber: string; name: string; reason: string }>;
}) {
  const lines = [
    "# USVI Historic Sites Audit",
    "",
    `Generated: ${audit.generatedAt}`,
    "",
    "## Coverage",
    "",
    ...Object.entries(audit.counts).map(([key, value]) => `- ${humanize(key)}: **${value}**`),
    "",
    "## Coordinate policy",
    "",
    "- NPS point features are imported as verified public coordinates.",
    "- NPS polygon features use a representative map point and are labeled representative, not exact.",
    "- Restricted records are excluded.",
    "- Records without a public NPS spatial feature remain unresolved rather than receiving invented coordinates.",
    "",
    "## Sources",
    "",
    ...Object.entries(audit.sources).map(([key, value]) => `- ${humanize(key)}: ${value}`),
    "",
    "## Unresolved official listings",
    "",
  ];

  if (!audit.unresolved.length) lines.push("None.");
  else {
    lines.push("| Ref # | Property | Reason |", "|---|---|---|");
    for (const item of audit.unresolved) {
      lines.push(`| ${item.refNumber} | ${item.name.replace(/\|/g, "\\|")} | ${item.reason} |`);
    }
  }
  return `${lines.join("\n")}\n`;
}

async function fetchText(url: string) {
  const response = await fetch(url, {
    headers: { "user-agent": "VI-Guide historic catalog sync/1.0" },
  });
  if (!response.ok) throw new Error(`GET ${url} failed: ${response.status} ${response.statusText}`);
  return response.text();
}

async function fetchJson<T>(url: string): Promise<T> {
  const response = await fetch(url, {
    headers: { "user-agent": "VI-Guide historic catalog sync/1.0" },
  });
  if (!response.ok) throw new Error(`GET ${url} failed: ${response.status} ${response.statusText}`);
  return (await response.json()) as T;
}

function readJson<T>(filePath: string, fallback: T): T {
  if (!fs.existsSync(filePath)) return fallback;
  return JSON.parse(fs.readFileSync(filePath, "utf8")) as T;
}

function writeJson(filePath: string, value: unknown) {
  fs.writeFileSync(filePath, `${JSON.stringify(value, null, 2)}\n`, "utf8");
}

function ensureParent(filePath: string) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
}

function pick(row: CsvRow, ...names: string[]) {
  for (const name of names) {
    const direct = row[name];
    if (direct !== undefined) return direct.trim();
    const key = Object.keys(row).find((item) => normalize(item) === normalize(name));
    if (key) return row[key].trim();
  }
  return "";
}

function splitAliases(value: string) {
  return unique(value.split(/\s*;\s*|\s*\|\s*/g).map((item) => item.trim()).filter(Boolean));
}

function slugify(value: string) {
  return normalize(value);
}

function normalize(value: string) {
  return value
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[’']/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

function clean(value: unknown) {
  return typeof value === "string" ? value.trim() : value == null ? "" : String(value).trim();
}

function unique(values: string[]) {
  return [...new Set(values.map((value) => value.trim()).filter(Boolean))];
}

function validLatLng(lat: number, lng: number) {
  return Number.isFinite(lat) && Number.isFinite(lng) && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180;
}

function insideUsvi(lat: number, lng: number) {
  return lat >= 17.55 && lat <= 18.5 && lng >= -65.2 && lng <= -64.45;
}

function islandName(island: IslandCode) {
  return island === "stt" ? "St. Thomas" : island === "stj" ? "St. John" : "St. Croix";
}

function decodeHtml(value: string) {
  return value.replace(/&amp;/g, "&");
}

function humanize(value: string) {
  return value.replace(/([a-z])([A-Z])/g, "$1 $2").replace(/[-_]/g, " ").replace(/^./, (char) => char.toUpperCase());
}

main().catch((error) => {
  console.error(error instanceof Error ? error.stack ?? error.message : error);
  process.exitCode = 1;
});
