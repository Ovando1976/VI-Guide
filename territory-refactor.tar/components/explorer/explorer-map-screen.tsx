"use client";

import dynamic from "next/dynamic";
import { useRouter, useSearchParams } from "next/navigation";
import {
  useCallback,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import type { LineString } from "geojson";

import { ViConcierge } from "@/components/concierge/vi-concierge";
import type { ConciergeContext } from "@/types/concierge";
import { MobilityActionDock } from "@/components/explorer/mobility-action-dock";
import { TerritoryIntelligenceRail } from "@/components/explorer/territory-intelligence-rail";
import type {
  TerritoryMapLens as Lens,
  TerritoryMapSelection,
  TerritorySelection,
  TerritoryState,
} from "@/types/territory-map";
import { TerritoryKpiBar } from "@/components/explorer/territory-kpi-bar";
import { TerritoryMapWorkspace } from "@/components/explorer/territory-map-workspace";
import {
  queryTerritoryEntities,
  queryTerritoryMapPlaces,
} from "@/lib/territory";
import { ISLAND_META, searchEstates } from "@/lib/usvi";
import type { RideMode } from "@/types/mobility";
import type { TerritoryEntity } from "@/types/territory";
import type { EstateRecord, IslandCode } from "@/types/usvi";

const EstateMap = dynamic(
  () => import("@/components/estate-map").then((module) => module.EstateMap),
  {
    ssr: false,
    loading: () => (
      <div className="min-h-[500px] w-full animate-pulse rounded-2xl border border-white/10 bg-white/[0.04] md:min-h-[620px]" />
    ),
  }
);

type MapMode = "arrival" | "stay" | "discovery";
type RouteStatus = "idle" | "loading" | "ready" | "error";
type RouteMetrics = { distanceMeters: number; durationSeconds: number };
type DirectoryPositionFilter = "all" | "positioned" | "unpositioned";

const syntheticOperationsEnabled =
  process.env.NEXT_PUBLIC_ENABLE_SYNTHETIC_OPERATIONS === "true";

const DEFAULT_ESTATE_BY_ISLAND: Record<IslandCode, string[]> = {
  stt: ["kings quarter", "charlotte amalie", "bovoni", "airport"],
  stj: ["cruz bay", "enighed", "carolina"],
  stx: ["christiansted", "frederiksted", "kings quarter"],
};

const QUICK_ROUTE_PRESETS: Record<
  string,
  { island: IslandCode; mode: RideMode; fromMatch: string[]; toMatch: string[] }
> = {
  "Airport transfer": {
    island: "stt",
    mode: "airport",
    fromMatch: ["airport", "cyril e king"],
    toMatch: ["charlotte amalie", "red hook", "bovoni"],
  },
  "Red Hook ferry": {
    island: "stt",
    mode: "ferry-transfer",
    fromMatch: ["red hook"],
    toMatch: ["charlotte amalie", "bovoni"],
  },
  "Charlotte Amalie": {
    island: "stt",
    mode: "standard",
    fromMatch: ["charlotte amalie"],
    toMatch: ["bovoni", "red hook"],
  },
  "Cruz Bay run": {
    island: "stj",
    mode: "standard",
    fromMatch: ["cruz bay"],
    toMatch: ["carolina", "enighed"],
  },
  "Safari ride": {
    island: "stt",
    mode: "shared",
    fromMatch: ["charlotte amalie", "bovoni"],
    toMatch: ["red hook", "kings quarter"],
  },
  "Resort pickup": {
    island: "stt",
    mode: "premium",
    fromMatch: ["bovoni", "red hook"],
    toMatch: ["charlotte amalie", "airport"],
  },
};

const ISLAND_SPOTLIGHT: Record<
  IslandCode,
  { title: string; focus: string; route: string; tags: string[] }
> = {
  stt: {
    title: "St. Thomas",
    focus: "Airport, harbor, resorts, town, and hillside access",
    route: "Cyril E. King → Charlotte Amalie → Red Hook",
    tags: ["harbor-linked", "resort corridor", "east-end connector"],
  },
  stj: {
    title: "St. John",
    focus: "Ferry arrivals, villas, beaches, and Cruz Bay",
    route: "Cruz Bay → North Shore → villa pickup",
    tags: ["ferry-first", "beach corridor", "villa access"],
  },
  stx: {
    title: "St. Croix",
    focus: "Airport, Christiansted, Frederiksted, and cross-island corridors",
    route: "Airport → Christiansted → west end transfer",
    tags: ["territory-scale", "historic estates", "cross-island movement"],
  },
};

const BASE_LENS_ORDER: Record<MapMode, Lens[]> = {
  arrival: ["drivers", "places", "stays", "demand", "beaches", "historic"],
  stay: ["stays", "places", "beaches", "historic", "drivers", "demand"],
  discovery: ["places", "beaches", "historic", "stays", "drivers", "demand"],
};

function getLensOrder(mode: MapMode): Lens[] {
  return BASE_LENS_ORDER[mode].filter(
    (lens) =>
      syntheticOperationsEnabled || (lens !== "drivers" && lens !== "demand")
  );
}

function modeDefaults(mode: MapMode): { lens: Lens; rideMode: RideMode } {
  if (mode === "arrival") return { lens: "places", rideMode: "airport" };
  if (mode === "stay") return { lens: "stays", rideMode: "premium" };
  return { lens: "places", rideMode: "standard" };
}

function validMode(value: string | null): MapMode {
  return value === "arrival" || value === "stay" ? value : "discovery";
}

function validIsland(value: string | null): IslandCode | null {
  const normalized = value?.trim().toLowerCase();
  return normalized === "stt" || normalized === "stj" || normalized === "stx"
    ? normalized
    : null;
}

function findEstateByMatchers(estates: EstateRecord[], matchers: string[]) {
  const searchable = estates.map((estate) => ({
    estate,
    text: `${estate.baseName} ${estate.fullName} ${
      estate.estateCode ?? ""
    }`.toLowerCase(),
  }));

  for (const matcher of matchers) {
    const match = searchable.find((item) =>
      item.text.includes(matcher.toLowerCase())
    );
    if (match) return match.estate;
  }

  return null;
}

function inferEstateTags(estate: EstateRecord | null, island: IslandCode) {
  if (!estate) return ISLAND_SPOTLIGHT[island].tags;

  const text = `${estate.baseName} ${estate.fullName}`.toLowerCase();
  const tags = new Set<string>();

  if (/bay|harbor|hook|amalie/.test(text)) tags.add("harbor-linked");
  if (/airport|king|terminal/.test(text)) tags.add("airport-adjacent");
  if (/east|red hook|smith|nazareth/.test(text)) tags.add("east-end connector");
  if (/mount|hill|ridge|heights/.test(text)) tags.add("hillside access");
  if (/cruz|enighed|carolina/.test(text)) tags.add("ferry-first");
  if (/christiansted|frederiksted|company|prince/.test(text)) {
    tags.add("historic corridor");
  }

  if (!tags.size) {
    ISLAND_SPOTLIGHT[island].tags.forEach((tag) => tags.add(tag));
  }

  return [...tags];
}

function squaredDistance(a: EstateRecord, b: EstateRecord) {
  const lat = a.internalPoint.lat - b.internalPoint.lat;
  const lng = a.internalPoint.lng - b.internalPoint.lng;
  return lat * lat + lng * lng;
}

function entityMatchesLens(entity: TerritoryEntity, lens: Lens) {
  if (lens === "beaches") return entity.kind === "beach";
  if (lens === "stays") return entity.kind === "stay";
  if (lens === "historic") return entity.kind === "historic";
  if (lens === "places") return entity.kind === "place";
  return false;
}

function entitySearchText(entity: TerritoryEntity) {
  return [
    entity.title,
    entity.summary,
    entity.description,
    entity.kind,
    entity.island,
    ...(entity.tags ?? []),
  ]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();
}

function entitySubtitle(entity: TerritoryEntity) {
  return (
    entity.summary ??
    entity.description ??
    entity.tags?.slice(0, 3).join(" · ") ??
    `${entity.kind} on ${entity.island.toUpperCase()}`
  );
}

function entityKindLabel(kind: TerritoryEntity["kind"]) {
  if (kind === "beach") return "Beach";
  if (kind === "stay") return "Stay";
  if (kind === "historic") return "Historic";
  if (kind === "place") return "Place";
  return kind;
}

export function ExplorerMapScreen() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const [estates, setEstates] = useState<EstateRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [reloadNonce, setReloadNonce] = useState(0);

  const [query, setQuery] = useState("");
  const [mode, setMode] = useState<RideMode>("standard");
  const [modeContext, setModeContext] = useState<MapMode>("discovery");
  const [territory, setTerritory] = useState<TerritoryState>({
    island: "stt",
    lens: "places",
    selection: null,
    pickupGeoid: null,
    destinationGeoid: null,
  });
  const [passengers, setPassengers] = useState(1);
  const [luggage, setLuggage] = useState(0);

  const [routeGeoJson, setRouteGeoJson] = useState<LineString | null>(null);
  const [routeFocusNonce, setRouteFocusNonce] = useState(0);
  const [routeStatus, setRouteStatus] = useState<RouteStatus>("idle");
  const [routeMessage, setRouteMessage] = useState<string | null>(null);
  const [routeMetrics, setRouteMetrics] = useState<RouteMetrics | null>(null);

  const [directoryPositionFilter, setDirectoryPositionFilter] =
    useState<DirectoryPositionFilter>("all");

  const [directoryExpanded, setDirectoryExpanded] = useState(false);
  const island = territory.island;
  const activeLens = territory.lens;
  const selection = territory.selection;
  const fromGeoid = territory.pickupGeoid ?? "";
  const toGeoid = territory.destinationGeoid ?? "";
  const selectedEstateGeoid =
    selection?.kind === "estate" ? selection.geoid : null;

  const selectedTerritoryPlace =
    selection?.kind === "place" ? selection.place : null;

  const handleChangeIsland = useCallback((nextIsland: IslandCode) => {
    setTerritory((current) => ({
      ...current,
      island: nextIsland,
      selection: null,
      pickupGeoid: null,
      destinationGeoid: null,
    }));

    setQuery("");
    setRouteGeoJson(null);
    setRouteStatus("idle");
    setRouteMessage(null);
    setRouteMetrics(null);
    setDirectoryPositionFilter("all");
    setDirectoryExpanded(false);

    window.localStorage.setItem("vi-guide.active-island", nextIsland);
  }, []);

  const handleSelectFrom = useCallback((geoid: string) => {
    setTerritory((current) => ({
      ...current,
      pickupGeoid: geoid || null,
      destinationGeoid:
        geoid && geoid === current.destinationGeoid
          ? null
          : current.destinationGeoid,
    }));
  }, []);

  const handleSelectTo = useCallback((geoid: string) => {
    setTerritory((current) => ({
      ...current,
      destinationGeoid: geoid || null,
      pickupGeoid:
        geoid && geoid === current.pickupGeoid ? null : current.pickupGeoid,
    }));
  }, []);

  const handleChangeLens = useCallback((lens: Lens) => {
    const nextLens =
      !syntheticOperationsEnabled && (lens === "drivers" || lens === "demand")
        ? "places"
        : lens;

    setTerritory((current) => ({
      ...current,
      lens: nextLens,
      selection: current.selection?.kind === "place" ? null : current.selection,
    }));
  }, []);

  const handleSelectEstate = useCallback((estate: EstateRecord | null) => {
    setTerritory((current) => ({
      ...current,
      selection: estate
        ? {
            kind: "estate",
            geoid: estate.geoid,
          }
        : null,
    }));
  }, []);

  const handleSelectEstateGeoid = useCallback((geoid: string | null) => {
    setTerritory((current) => ({
      ...current,
      selection: geoid
        ? {
            kind: "estate",
            geoid,
          }
        : null,
    }));
  }, []);

  const handleSelectTerritoryPlace = useCallback(
    (place: TerritoryMapSelection | null) => {
      setTerritory((current) => ({
        ...current,
        selection: place
          ? {
              kind: "place",
              place,
            }
          : null,
      }));
    },
    []
  );
  useEffect(() => {
    const controller = new AbortController();

    async function loadEstates() {
      try {
        setLoading(true);
        setLoadError(null);

        const response = await fetch("/api/estates", {
          cache: "no-store",
          signal: controller.signal,
        });
        const payload = await response.json().catch(() => null);

        if (!response.ok) {
          throw new Error(payload?.error ?? "Failed to load estates.");
        }

        const loaded = Array.isArray(payload?.estates)
          ? (payload.estates as EstateRecord[])
          : [];

        setEstates(loaded);

        if (!loaded.length) {
          setLoadError("No estate records were returned from the API.");
        }
      } catch (error) {
        if (controller.signal.aborted) return;
        setLoadError(
          error instanceof Error ? error.message : "Failed to load estates."
        );
      } finally {
        if (!controller.signal.aborted) setLoading(false);
      }
    }

    loadEstates();
    return () => controller.abort();
  }, [reloadNonce]);

  useEffect(() => {
    const context = validMode(searchParams.get("mode"));
    const defaults = modeDefaults(context);

    const nextLens =
      !syntheticOperationsEnabled &&
      (defaults.lens === "drivers" || defaults.lens === "demand")
        ? "places"
        : defaults.lens;

    const requestedIsland = validIsland(searchParams.get("island"));
    const rememberedIsland = validIsland(
      window.localStorage.getItem("vi-guide.active-island")
    );

    setModeContext(context);
    setMode(defaults.rideMode);

    setTerritory((current) => ({
      ...current,
      island: requestedIsland ?? rememberedIsland ?? current.island,
      lens: nextLens,
    }));
  }, [searchParams]);

  useEffect(() => {
    window.localStorage.setItem("vi-guide.active-island", island);
  }, [island]);

  useEffect(() => {
    window.localStorage.setItem(
      "vi-guide.trip-draft",
      JSON.stringify({
        island,
        from: fromGeoid,
        to: toGeoid,
        mode,
        passengers,
        luggage,
      })
    );
  }, [island, fromGeoid, toGeoid, mode, passengers, luggage]);

  useEffect(() => {
    const requestedEstate = searchParams.get("estate");
    if (!requestedEstate || !estates.length) return;

    const match = estates.find((estate) => estate.geoid === requestedEstate);
    if (!match) return;

    setTerritory((current) => ({
      ...current,
      island: match.island,
      selection: {
        kind: "estate",
        geoid: match.geoid,
      },
      pickupGeoid: modeContext === "stay" ? match.geoid : current.pickupGeoid,
    }));
  }, [searchParams, estates, modeContext]);

  const islandEstates = useMemo(
    () => estates.filter((estate) => estate.island === island),
    [estates, island]
  );

  const filteredEstates = useMemo(
    () => searchEstates(estates, query, island),
    [estates, query, island]
  );

  useEffect(() => {
    if (!islandEstates.length) return;

    const selectedIsValid = islandEstates.some(
      (estate) => estate.geoid === selectedEstateGeoid
    );

    setTerritory((current) => {
      let next = current;

      if (!selectedIsValid && current.selection?.kind === "estate") {
        next = {
          ...next,
          selection: null,
        };
      }

      if (modeContext === "stay" && !next.pickupGeoid) {
        const fallback =
          findEstateByMatchers(
            islandEstates,
            DEFAULT_ESTATE_BY_ISLAND[island]
          ) ?? islandEstates[0];

        next = {
          ...next,
          pickupGeoid: fallback.geoid,
        };
      }

      if (modeContext === "arrival" && !next.pickupGeoid) {
        const airport = findEstateByMatchers(islandEstates, [
          "airport",
          "cyril e king",
          "rohlsen",
        ]);

        if (airport) {
          next = {
            ...next,
            pickupGeoid: airport.geoid,
          };
        }
      }

      return next;
    });
  }, [islandEstates, selectedEstateGeoid, island, modeContext]);

  const selectedEstate =
    estates.find((estate) => estate.geoid === selectedEstateGeoid) ?? null;
  const fromEstate =
    islandEstates.find((estate) => estate.geoid === fromGeoid) ?? null;
  const toEstate =
    islandEstates.find((estate) => estate.geoid === toGeoid) ?? null;

  // Complete canonical directory: includes positioned and unresolved entities.
  const allIslandEntities = useMemo(
    () =>
      queryTerritoryEntities({ island }).filter(
        (entity) => entity.kind !== "estate"
      ),
    [island]
  );

  // Map markers: only entities with valid coordinates.
  const allIslandPlaces = useMemo(
    () => queryTerritoryMapPlaces({ island }),
    [island]
  );

  const islandPlaces = useMemo(() => {
    if (activeLens === "beaches") {
      return allIslandPlaces.filter((place) => place.type === "beach");
    }
    if (activeLens === "stays") {
      return allIslandPlaces.filter((place) => place.type === "stay");
    }
    if (activeLens === "historic") {
      return allIslandPlaces.filter((place) => place.type === "historic");
    }
    if (activeLens === "places") {
      return allIslandPlaces.filter((place) => place.type === "place");
    }
    return [];
  }, [allIslandPlaces, activeLens]);

  const directoryEntities = useMemo(() => {
    if (activeLens === "drivers" || activeLens === "demand") return [];

    const normalizedQuery = query.trim().toLowerCase();

    return allIslandEntities
      .filter((entity) => entityMatchesLens(entity, activeLens))
      .filter((entity) => {
        if (!normalizedQuery) return true;
        return entitySearchText(entity).includes(normalizedQuery);
      })
      .filter((entity) => {
        if (directoryPositionFilter === "positioned") {
          return Boolean(entity.position);
        }
        if (directoryPositionFilter === "unpositioned") {
          return !entity.position;
        }
        return true;
      })
      .sort((a, b) => {
        if (Boolean(a.position) !== Boolean(b.position)) {
          return a.position ? -1 : 1;
        }
        return a.title.localeCompare(b.title);
      });
  }, [activeLens, allIslandEntities, directoryPositionFilter, query]);

  const visibleDirectoryEntities = useMemo(
    () =>
      directoryExpanded ? directoryEntities : directoryEntities.slice(0, 18),
    [directoryEntities, directoryExpanded]
  );

  const catalogStats = useMemo(() => {
    const positioned = allIslandEntities.filter((entity) =>
      Boolean(entity.position)
    ).length;

    return {
      total: allIslandEntities.length,
      positioned,
      unresolved: allIslandEntities.length - positioned,
      visibleDirectory: directoryEntities.length,
      visibleMarkers: islandPlaces.length,
    };
  }, [allIslandEntities, directoryEntities.length, islandPlaces.length]);

  useEffect(() => {
    setDirectoryExpanded(false);
  }, [activeLens, directoryPositionFilter, island, query]);

  useEffect(() => {
    if (process.env.NODE_ENV !== "development") return;

    console.table({
      island,
      activeLens,
      catalogTotal: catalogStats.total,
      catalogPositioned: catalogStats.positioned,
      catalogUnresolved: catalogStats.unresolved,
      directoryMatches: catalogStats.visibleDirectory,
      mapMarkers: catalogStats.visibleMarkers,
      places: allIslandEntities.filter((entity) => entity.kind === "place")
        .length,
      beaches: allIslandEntities.filter((entity) => entity.kind === "beach")
        .length,
      stays: allIslandEntities.filter((entity) => entity.kind === "stay")
        .length,
      historic: allIslandEntities.filter((entity) => entity.kind === "historic")
        .length,
    });
  }, [activeLens, allIslandEntities, catalogStats, island]);

  const selectedPlaceEstate = useMemo(() => {
    if (!selectedTerritoryPlace || !islandEstates.length) return null;

    return (
      islandEstates
        .map((estate) => ({
          estate,
          distance:
            Math.pow(estate.internalPoint.lat - selectedTerritoryPlace.lat, 2) +
            Math.pow(estate.internalPoint.lng - selectedTerritoryPlace.lng, 2),
        }))
        .sort((a, b) => a.distance - b.distance)[0]?.estate ?? null
    );
  }, [islandEstates, selectedTerritoryPlace]);

  const contextEstate = selectedEstate ?? selectedPlaceEstate;

  const neighboringEstates = useMemo(() => {
    if (!contextEstate) return [];

    return islandEstates
      .filter((estate) => estate.geoid !== contextEstate.geoid)
      .sort(
        (a, b) =>
          squaredDistance(contextEstate, a) - squaredDistance(contextEstate, b)
      )
      .slice(0, 5);
  }, [contextEstate, islandEstates]);

  useEffect(() => {
    if (!fromEstate || !toEstate) {
      setRouteGeoJson(null);
      setRouteStatus("idle");
      setRouteMessage(null);
      setRouteMetrics(null);
      return;
    }

    const controller = new AbortController();
    const routeFrom = fromEstate.internalPoint;
    const routeTo = toEstate.internalPoint;

    async function loadRoute() {
      try {
        setRouteStatus("loading");
        setRouteMessage("Calculating the roadway route");

        const response = await fetch("/api/route", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          signal: controller.signal,
          body: JSON.stringify({
            from: routeFrom,
            to: routeTo,
          }),
        });
        const payload = await response.json().catch(() => null);

        if (!response.ok) {
          throw new Error(payload?.error ?? "Roadway route unavailable.");
        }

        if (
          payload?.geometry?.type !== "LineString" ||
          !Array.isArray(payload.geometry.coordinates)
        ) {
          throw new Error("The routing provider returned an invalid route.");
        }

        setRouteGeoJson(payload.geometry as LineString);
        setRouteMetrics({
          distanceMeters:
            typeof payload.distanceMeters === "number"
              ? payload.distanceMeters
              : 0,
          durationSeconds:
            typeof payload.durationSeconds === "number"
              ? payload.durationSeconds
              : 0,
        });
        setRouteStatus("ready");
        setRouteMessage("Roadway route ready");
        setRouteFocusNonce((value) => value + 1);
      } catch (error) {
        if (controller.signal.aborted) return;

        setRouteGeoJson(null);
        setRouteMetrics(null);
        setRouteStatus("error");
        setRouteMessage(
          error instanceof Error ? error.message : "Roadway route unavailable."
        );
      }
    }

    loadRoute();
    return () => controller.abort();
  }, [fromEstate, toEstate]);

  function continueToBooking() {
    if (!fromEstate || !toEstate || fromEstate.geoid === toEstate.geoid) return;

    const params = new URLSearchParams({
      island,
      from: fromEstate.geoid,
      to: toEstate.geoid,
      mode,
      passengers: String(passengers),
      luggage: String(luggage),
    });

    router.push(`/mobility?${params.toString()}`);
  }

  const hero = ISLAND_META[island];
  const spotlight = ISLAND_SPOTLIGHT[island];
  const routeReady = Boolean(
    fromEstate && toEstate && fromEstate.geoid !== toEstate.geoid
  );

  const conciergeContext = useMemo<ConciergeContext>(
    () => ({
      island,
      islandName: hero.name,
      selectedEstate: selectedEstate
        ? {
            geoid: selectedEstate.geoid,
            name: selectedEstate.baseName,
          }
        : null,
      pickup: fromEstate
        ? {
            geoid: fromEstate.geoid,
            name: fromEstate.baseName,
          }
        : null,
      destination: toEstate
        ? {
            geoid: toEstate.geoid,
            name: toEstate.baseName,
          }
        : null,
      rideMode: mode,
      passengers,
      luggage,
      activeLens,
      nearbyEstates: neighboringEstates.map((estate) => ({
        geoid: estate.geoid,
        name: estate.baseName,
      })),
    }),
    [
      island,
      hero.name,
      selectedEstate,
      fromEstate,
      toEstate,
      mode,
      passengers,
      luggage,
      activeLens,
      neighboringEstates,
    ]
  );

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top_right,rgba(14,116,144,0.12),transparent_30%),linear-gradient(180deg,#041018_0%,#07131a_45%,#09161f_100%)] text-white">
      <main className="mx-auto max-w-[1800px] space-y-4 px-3 pb-24 pt-3 md:px-6 md:pb-28 md:pt-4">
        {loading ? (
          <LoadingState />
        ) : loadError ? (
          <ErrorState
            message={loadError}
            onRetry={() => setReloadNonce((value) => value + 1)}
          />
        ) : (
          <>
            <TerritoryKpiBar
              islandName={hero.name}
              visibleEstates={filteredEstates.length}
              selectedEstate={selectedEstate?.baseName ?? "None"}
              pickup={fromEstate?.baseName ?? "Not set"}
              destination={toEstate?.baseName ?? "Not set"}
              mode={mode}
              passengers={passengers}
              luggage={luggage}
            />

            <section
              id="territory-workspace"
              className="scroll-mt-40 grid gap-4 xl:grid-cols-[minmax(0,1.75fr)_390px]"
            >
              <TerritoryMapWorkspace
                activeLens={activeLens}
                onChangeLens={handleChangeLens}
                lensOrder={getLensOrder(modeContext)}
                manifestCount={filteredEstates.length}
                estates={filteredEstates}
                selectedEstateGeoid={selectedEstateGeoid}
                fromGeoid={fromGeoid}
                toGeoid={toGeoid}
                onSelectEstate={(geoid) => handleSelectEstateGeoid(geoid)}
                routeStatus={routeStatus}
                routeMessage={routeMessage}
                manifestAction={(estate) => (
                  <>
                    <button
                      type="button"
                      disabled={toGeoid === estate.geoid}
                      onClick={() => {
                        handleSelectFrom(estate.geoid);
                        handleSelectEstateGeoid(estate.geoid);
                      }}
                      className="rounded-full border border-white/10 px-3 py-1.5 text-[10px] font-bold text-white/65 transition hover:bg-white/10 hover:text-white disabled:opacity-35"
                    >
                      Pickup
                    </button>
                    <button
                      type="button"
                      disabled={fromGeoid === estate.geoid}
                      onClick={() => {
                        handleSelectTo(estate.geoid);
                        handleSelectEstateGeoid(estate.geoid);
                      }}
                      className="rounded-full border border-white/10 px-3 py-1.5 text-[10px] font-bold text-white/65 transition hover:bg-white/10 hover:text-white disabled:opacity-35"
                    >
                      Destination
                    </button>
                  </>
                )}
              >
                <EstateMap
                  island={island}
                  estates={filteredEstates}
                  // Give EstateMap the complete positioned catalog. EstateMap
                  // owns active-lens visibility and its per-layer counters.
                  places={allIslandPlaces}
                  activeLens={activeLens}
                  selectedEstateGeoid={selectedEstateGeoid}
                  fromGeoid={fromGeoid}
                  toGeoid={toGeoid}
                  routeGeoJson={routeGeoJson}
                  routeFocusNonce={routeFocusNonce}
                  onSelectEstate={handleSelectEstate}
                  onSelectPlace={handleSelectTerritoryPlace}
                  onSelectFrom={handleSelectFrom}
                  onSelectTo={handleSelectTo}
                  onChangeLens={handleChangeLens}
                />
              </TerritoryMapWorkspace>

              <TerritoryIntelligenceRail
                islandTitle={spotlight.title}
                islandFocus={spotlight.focus}
                signatureRoute={spotlight.route}
                selectedEstate={selectedEstate}
                selectedPlace={selectedTerritoryPlace}
                selectedPlaceEstate={selectedPlaceEstate}
                fromEstate={fromEstate}
                toEstate={toEstate}
                estateTags={inferEstateTags(contextEstate, island)}
                neighboringEstates={neighboringEstates}
                onSelectNeighbor={(geoid) => handleSelectEstateGeoid(geoid)}
                onUseAsPickup={handleSelectFrom}
                onUseAsDestination={handleSelectTo}
                routeReady={routeReady}
              />
            </section>

            <TerritoryDirectory
              activeLens={activeLens}
              islandName={hero.name}
              entities={visibleDirectoryEntities}
              totalMatching={directoryEntities.length}
              totalCatalog={catalogStats.total}
              positionedCount={catalogStats.positioned}
              unresolvedCount={catalogStats.unresolved}
              markerCount={catalogStats.visibleMarkers}
              positionFilter={directoryPositionFilter}
              onChangePositionFilter={setDirectoryPositionFilter}
              expanded={directoryExpanded}
              onToggleExpanded={() =>
                setDirectoryExpanded((current) => !current)
              }
            />

            <MobilityActionDock
              estates={islandEstates}
              fromGeoid={fromGeoid}
              toGeoid={toGeoid}
              fromEstate={fromEstate}
              toEstate={toEstate}
              mode={mode}
              passengers={passengers}
              luggage={luggage}
              onSelectFrom={handleSelectFrom}
              onSelectTo={handleSelectTo}
              onChangeMode={setMode}
              onChangePassengers={(value) =>
                setPassengers(Math.max(1, Math.min(12, value || 1)))
              }
              onChangeLuggage={(value) =>
                setLuggage(Math.max(0, Math.min(12, value || 0)))
              }
              onSubmit={continueToBooking}
              distanceMeters={routeMetrics?.distanceMeters}
              durationSeconds={routeMetrics?.durationSeconds}
            />
          </>
        )}
      </main>

      <ViConcierge
        context={conciergeContext}
        onSelectEstate={(geoid) => handleSelectEstateGeoid(geoid)}
        onSetPickup={handleSelectFrom}
        onSetDestination={handleSelectTo}
        placement="right"
        initiallyOpen={searchParams.get("concierge") === "open"}
      />
    </div>
  );
}

function TerritoryDirectory({
  activeLens,
  islandName,
  entities,
  totalMatching,
  totalCatalog,
  positionedCount,
  unresolvedCount,
  markerCount,
  positionFilter,
  onChangePositionFilter,
  expanded,
  onToggleExpanded,
}: {
  activeLens: Lens;
  islandName: string;
  entities: TerritoryEntity[];
  totalMatching: number;
  totalCatalog: number;
  positionedCount: number;
  unresolvedCount: number;
  markerCount: number;
  positionFilter: DirectoryPositionFilter;
  onChangePositionFilter: (filter: DirectoryPositionFilter) => void;
  expanded: boolean;
  onToggleExpanded: () => void;
}) {
  const hasDirectory = activeLens !== "drivers" && activeLens !== "demand";

  return (
    <section className="overflow-hidden rounded-[28px] border border-white/10 bg-white/[0.035]">
      <div className="border-b border-white/10 px-4 py-4 md:px-6">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <div className="text-[10px] font-extrabold uppercase tracking-[0.2em] text-cyan-100/55">
              Complete territory directory
            </div>
            <h2 className="mt-1 text-xl font-extrabold tracking-tight text-white">
              {islandName} knowledge catalog
            </h2>
            <p className="mt-1 max-w-3xl text-sm leading-6 text-white/55">
              The directory includes every canonical catalog entry for the
              active lens, including records whose coordinates are still
              awaiting verification. Only positioned records become map markers.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            <DirectoryStat label="Catalog" value={totalCatalog} />
            <DirectoryStat label="Positioned" value={positionedCount} />
            <DirectoryStat label="Unresolved" value={unresolvedCount} />
            <DirectoryStat label="Markers" value={markerCount} />
          </div>
        </div>

        {hasDirectory ? (
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <DirectoryFilterButton
              active={positionFilter === "all"}
              onClick={() => onChangePositionFilter("all")}
            >
              All entries
            </DirectoryFilterButton>
            <DirectoryFilterButton
              active={positionFilter === "positioned"}
              onClick={() => onChangePositionFilter("positioned")}
            >
              Positioned
            </DirectoryFilterButton>
            <DirectoryFilterButton
              active={positionFilter === "unpositioned"}
              onClick={() => onChangePositionFilter("unpositioned")}
            >
              Awaiting coordinates
            </DirectoryFilterButton>

            <div className="ml-auto text-xs font-semibold text-white/45">
              {totalMatching} matching{" "}
              {totalMatching === 1 ? "entry" : "entries"}
            </div>
          </div>
        ) : null}
      </div>

      {!hasDirectory ? (
        <div className="px-4 py-10 text-center md:px-6">
          <div className="text-sm font-bold text-white">
            This lens uses a live operational overlay.
          </div>
          <p className="mx-auto mt-2 max-w-xl text-sm leading-6 text-white/50">
            Driver and demand layers do not map to static territory catalog
            entries.
          </p>
        </div>
      ) : entities.length ? (
        <>
          <div className="grid gap-3 p-4 md:grid-cols-2 md:p-6 2xl:grid-cols-3">
            {entities.map((entity) => (
              <TerritoryEntityCard key={entity.id} entity={entity} />
            ))}
          </div>

          {totalMatching > 18 ? (
            <div className="border-t border-white/10 px-4 py-4 text-center md:px-6">
              <button
                type="button"
                onClick={onToggleExpanded}
                className="rounded-xl border border-white/10 bg-white/[0.04] px-4 py-2.5 text-xs font-extrabold text-white/70 transition hover:bg-white/[0.08] hover:text-white"
              >
                {expanded
                  ? "Show first 18 entries"
                  : `Show all ${totalMatching} entries`}
              </button>
            </div>
          ) : null}
        </>
      ) : (
        <div className="px-4 py-10 text-center md:px-6">
          <div className="text-sm font-bold text-white">
            No catalog entries match these filters.
          </div>
          <p className="mt-2 text-sm text-white/50">
            Change the search, active lens, or coordinate-status filter.
          </p>
        </div>
      )}
    </section>
  );
}

function TerritoryEntityCard({ entity }: { entity: TerritoryEntity }) {
  return (
    <article className="flex min-h-40 flex-col rounded-2xl border border-white/10 bg-black/10 p-4 transition hover:border-white/20 hover:bg-white/[0.035]">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-cyan-100/55">
            {entityKindLabel(entity.kind)}
          </div>
          <h3 className="mt-1 truncate text-base font-extrabold tracking-tight text-white">
            {entity.title}
          </h3>
        </div>

        <span
          className={
            entity.position
              ? "shrink-0 rounded-full border border-emerald-300/20 bg-emerald-300/[0.08] px-2 py-1 text-[9px] font-extrabold uppercase tracking-[0.12em] text-emerald-100/70"
              : "shrink-0 rounded-full border border-amber-300/20 bg-amber-300/[0.08] px-2 py-1 text-[9px] font-extrabold uppercase tracking-[0.12em] text-amber-100/70"
          }
        >
          {entity.position ? "Mapped" : "Unresolved"}
        </span>
      </div>

      <p className="mt-3 line-clamp-3 text-sm leading-6 text-white/55">
        {entitySubtitle(entity)}
      </p>

      <div className="mt-auto flex flex-wrap gap-1.5 pt-4">
        {(entity.tags ?? []).slice(0, 4).map((tag) => (
          <span
            key={tag}
            className="rounded-full border border-white/10 px-2 py-1 text-[9px] font-bold text-white/45"
          >
            {tag}
          </span>
        ))}
      </div>
    </article>
  );
}

function DirectoryStat({ label, value }: { label: string; value: number }) {
  return (
    <div className="min-w-24 rounded-xl border border-white/10 bg-black/10 px-3 py-2">
      <div className="text-[9px] font-extrabold uppercase tracking-[0.14em] text-white/40">
        {label}
      </div>
      <div className="mt-0.5 text-lg font-extrabold text-white">{value}</div>
    </div>
  );
}

function DirectoryFilterButton({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={
        active
          ? "rounded-full border border-cyan-200/25 bg-cyan-200/[0.10] px-3 py-1.5 text-[10px] font-extrabold text-cyan-50"
          : "rounded-full border border-white/10 px-3 py-1.5 text-[10px] font-extrabold text-white/50 transition hover:bg-white/[0.06] hover:text-white"
      }
    >
      {children}
    </button>
  );
}

function LoadingState() {
  return (
    <div className="grid gap-3" role="status" aria-live="polite">
      <div className="h-16 animate-pulse rounded-2xl bg-white/[0.05]" />
      <div className="min-h-[620px] animate-pulse rounded-[28px] border border-white/10 bg-white/[0.04]" />
      <span className="sr-only">Loading official estate geography</span>
    </div>
  );
}

function ErrorState({
  message,
  onRetry,
}: {
  message: string;
  onRetry: () => void;
}) {
  return (
    <section
      className="rounded-[28px] border border-rose-300/20 bg-rose-300/[0.07] p-6 md:p-8"
      role="alert"
    >
      <div className="text-[10px] font-extrabold uppercase tracking-[0.2em] text-rose-200/70">
        Estate data unavailable
      </div>
      <h2 className="mt-2 text-2xl font-extrabold tracking-tight text-white">
        The map could not load its estate layer.
      </h2>
      <p className="mt-3 max-w-2xl text-sm leading-6 text-rose-50/65">
        {message}
      </p>
      <button
        type="button"
        onClick={onRetry}
        className="mt-5 rounded-xl bg-white px-4 py-2.5 text-xs font-extrabold text-[#10242c] transition hover:bg-rose-50"
      >
        Try again
      </button>
    </section>
  );
}
