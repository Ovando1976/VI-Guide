import beachesJson from "@/data/travel-knowledge/beaches.json";
import historicJson from "@/data/travel-knowledge/historic-sites.json";
import placesJson from "@/data/travel-knowledge/places.json";
import { ACCOMMODATIONS } from "@/lib/accommodations";
import type { DirectoryItem } from "@/types/directory";

export type TravelKnowledgeKind = "places" | "beaches" | "historic" | "stays";

const PLACES = placesJson as DirectoryItem[];
const BEACHES = beachesJson as DirectoryItem[];
const HISTORIC = historicJson as DirectoryItem[];

export const TRAVEL_KNOWLEDGE: Record<TravelKnowledgeKind, DirectoryItem[]> = {
  places: PLACES,
  beaches: BEACHES,
  historic: HISTORIC,
  stays: ACCOMMODATIONS,
};

export function getTravelKnowledge(kind: TravelKnowledgeKind): DirectoryItem[] {
  return TRAVEL_KNOWLEDGE[kind];
}

export function getTravelKnowledgeItem(
  kind: TravelKnowledgeKind,
  slug: string
): DirectoryItem | undefined {
  return TRAVEL_KNOWLEDGE[kind].find((item) => item.slug === slug || item.id === slug);
}

export const ALL_PUBLIC_TRAVEL_KNOWLEDGE = [
  ...PLACES,
  ...BEACHES,
  ...HISTORIC,
  ...ACCOMMODATIONS,
];
